class AddHiddenToImagesAndTexts < ActiveRecord::Migration
  def change
  	add_column :images, :hidden, :boolean, default: false
  	add_column :texts, :hidden, :boolean, default: false
  end
end
