class CreateTexts < ActiveRecord::Migration
  def change
    create_table :texts do |t|
    	t.references	:ad
    	t.references	:frame
    	t.attachment	:file
        t.string        :name
    	t.string		:content
    	t.decimal		:x
    	t.decimal		:y
    	t.decimal		:width
    	t.decimal		:height
    	t.integer		:z_index
    	t.integer		:font_size
    	t.string	    :font_family
    	t.integer		:font_weight
    	t.string		:color
    	t.references	:google_font
    	t.references	:other_font
    	t.references	:animation

      t.timestamps null: false
    end
  end
end
