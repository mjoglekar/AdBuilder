class AddFileMetaToBackgrounds < ActiveRecord::Migration
  def change
    add_column :backgrounds,:file_meta, :text
  end
end
