class CreateElementAnimations < ActiveRecord::Migration
  def change
    create_table :element_animations do |t|
    	t.references	:image
    	t.references	:text
    	t.references	:animation
    	t.string			:name
    	t.string			:start_time
    	t.string			:duration

      t.timestamps null: false
    end
  end
end
