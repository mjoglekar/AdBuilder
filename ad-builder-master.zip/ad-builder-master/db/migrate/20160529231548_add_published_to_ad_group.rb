class AddPublishedToAdGroup < ActiveRecord::Migration
  def change
    add_column :ad_groups, :published, :boolean, default: false
  end
end
