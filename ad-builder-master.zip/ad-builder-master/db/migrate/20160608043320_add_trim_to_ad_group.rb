class AddTrimToAdGroup < ActiveRecord::Migration
  def change
    add_column :ad_groups, :trim, :string
  end
end
