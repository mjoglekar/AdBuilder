class AddTextUnderlineToText < ActiveRecord::Migration
  def change
  	 add_column :texts, :underline_text, :boolean, default: false
  end
end
