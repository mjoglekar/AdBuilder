class CreatePromotionalLogos < ActiveRecord::Migration
  def change
    create_table :promotional_logos do |t|
      t.string :name
      t.references :make
      t.attachment :file
      

      t.timestamps null: false
    end
  end
end
