class CreateFrames < ActiveRecord::Migration
  def change
    create_table :frames do |t|
    	t.integer			:order
    	t.decimal			:length
    	t.attachment	:screenshot

      t.timestamps null: false
    end
  end
end
