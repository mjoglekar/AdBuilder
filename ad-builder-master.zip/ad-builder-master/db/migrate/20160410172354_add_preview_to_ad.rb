class AddPreviewToAd < ActiveRecord::Migration
  def change
    add_attachment :ads, :preview
  end
end
