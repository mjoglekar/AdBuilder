class AddDefaultToIsTemplateToAdGroup < ActiveRecord::Migration
  def change
  	change_column :ad_groups, :is_template, :boolean, :default => false
  end
end
