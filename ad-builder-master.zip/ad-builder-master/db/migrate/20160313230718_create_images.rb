class CreateImages < ActiveRecord::Migration
  def change
    create_table :images do |t|
    	t.references	:ad
    	t.references	:frame
        t.string        :url
        t.string        :name
    	t.decimal		:x
    	t.decimal		:y
    	t.decimal		:width
    	t.decimal		:height
    	t.integer		:z_index
    	t.references	:client
    	t.references	:promotional_logo
    	t.references	:animation
        t.references    :car
    	t.references	:button

      t.timestamps null: false
    end
  end
end
