class AddTextAlignToText < ActiveRecord::Migration
  def change
  	 add_column :texts,:text_align, :string
  end
end
