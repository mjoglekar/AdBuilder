class CreateAdGroups < ActiveRecord::Migration
  def change
    create_table :ad_groups do |t|
    	t.references	:client
    	t.references	:template
    	t.references	:make
      t.timestamps null: false
    end
  end
end
