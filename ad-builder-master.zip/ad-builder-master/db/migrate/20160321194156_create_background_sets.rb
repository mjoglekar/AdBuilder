class CreateBackgroundSets < ActiveRecord::Migration
  def change
    create_table :background_sets do |t|
      t.string :name
      t.integer :ad_group_id
      t.timestamps null: false
    end
  end
end
