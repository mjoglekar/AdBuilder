class CreateTemplatesMakes < ActiveRecord::Migration
  def change
    create_table :templates_makes do |t|
      t.references :template, index: true, foreign_key: true
      t.references :make, index: true, foreign_key: true
    end
  end
end
