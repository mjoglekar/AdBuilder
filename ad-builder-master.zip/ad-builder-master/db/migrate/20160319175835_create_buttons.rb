class CreateButtons < ActiveRecord::Migration
  def change
    create_table :buttons do |t|
    	t.attachment	:file
    	t.references	:background_set

      t.timestamps null: false
    end
  end
end
