class AddItalicToText < ActiveRecord::Migration
  def change
  	add_column :texts, :italic, :boolean , default: false
  end
end
