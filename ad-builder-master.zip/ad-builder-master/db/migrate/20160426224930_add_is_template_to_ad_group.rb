class AddIsTemplateToAdGroup < ActiveRecord::Migration
  def change
    add_column :ad_groups, :is_template, :boolean
  end
end
