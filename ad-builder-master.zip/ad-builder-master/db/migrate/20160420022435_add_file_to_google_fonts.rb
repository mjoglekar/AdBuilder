class AddFileToGoogleFonts < ActiveRecord::Migration
  def change
  	add_attachment :google_fonts, :file
  end
end
