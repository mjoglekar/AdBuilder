class AddAdGroupToTemplate < ActiveRecord::Migration
  def change
    add_reference :templates, :ad_group, index: true, foreign_key: true
  end
end
