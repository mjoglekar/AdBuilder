class CreateOtherFonts < ActiveRecord::Migration
  def change
    create_table :other_fonts do |t|
    	t.attachment	:file
    	t.string			:name

      t.timestamps null: false
    end
  end
end
