class AddDownloadUrlToGoogleFonts < ActiveRecord::Migration
  def change
    add_column :google_fonts, :download_url, :string
  end
end
