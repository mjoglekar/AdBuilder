class CreateCars < ActiveRecord::Migration
  def change
    create_table :cars do |t|
    	t.references	:make
    	t.string			:year
    	t.string			:model
    	t.string			:trim
    	t.attachment	:file

      t.timestamps null: false
    end
  end
end
