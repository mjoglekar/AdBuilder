class AddAprToAdGroup < ActiveRecord::Migration
  def change
    add_column :ad_groups, :apr, :string
  end
end
