class CreateMakesBackgroundSets < ActiveRecord::Migration
  def change
    create_table :makes_background_sets do |t|
    	t.integer :background_set_id
  		t.integer :make_id
  		
      t.timestamps null: false
    end
  end
end
