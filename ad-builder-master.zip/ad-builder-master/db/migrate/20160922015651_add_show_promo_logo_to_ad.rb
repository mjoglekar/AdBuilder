class AddShowPromoLogoToAd < ActiveRecord::Migration
  def change
    add_column :ads, :show_promo_logo, :boolean, :default => false
  end
end
