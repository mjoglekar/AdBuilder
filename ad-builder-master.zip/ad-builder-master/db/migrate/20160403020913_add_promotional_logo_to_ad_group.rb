class AddPromotionalLogoToAdGroup < ActiveRecord::Migration
  def change
    add_reference :ad_groups, :promotional_logo, index: true, foreign_key: true
  end
end
