class AddInUseToGoogleFonts < ActiveRecord::Migration
  def change
    add_column :google_fonts, :in_use, :boolean, default: false
  end
end
