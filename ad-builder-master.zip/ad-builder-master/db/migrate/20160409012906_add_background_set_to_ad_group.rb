class AddBackgroundSetToAdGroup < ActiveRecord::Migration
  def change
    add_reference :ad_groups, :background_set, index: true, foreign_key: true
  end
end
