class AddCarToAdGroup < ActiveRecord::Migration
  def change
    add_reference :ad_groups, :car, index: true, foreign_key: true
  end
end
