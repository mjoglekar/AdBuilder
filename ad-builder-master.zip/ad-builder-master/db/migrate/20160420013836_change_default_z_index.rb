class ChangeDefaultZIndex < ActiveRecord::Migration
  def change
  	change_column_default(:texts, :z_index, 200)
  	change_column_default(:images, :z_index, 200)
  end
end
