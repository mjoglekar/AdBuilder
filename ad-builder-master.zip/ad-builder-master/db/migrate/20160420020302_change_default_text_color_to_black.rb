class ChangeDefaultTextColorToBlack < ActiveRecord::Migration
  def change
  	change_column_default(:texts, :color, '#000')
  end
end
