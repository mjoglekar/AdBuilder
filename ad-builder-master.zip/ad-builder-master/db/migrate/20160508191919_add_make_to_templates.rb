class AddMakeToTemplates < ActiveRecord::Migration
  def change
    add_reference :templates, :make, index: true, foreign_key: true
  end
end
