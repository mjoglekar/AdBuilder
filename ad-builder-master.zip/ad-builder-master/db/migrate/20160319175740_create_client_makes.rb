class CreateClientMakes < ActiveRecord::Migration
  def change
    create_table :client_makes do |t|
      t.references :client
      t.references :make

      t.timestamps null: false
    end
  end
end
