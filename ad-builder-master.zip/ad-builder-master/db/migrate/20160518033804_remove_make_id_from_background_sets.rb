class RemoveMakeIdFromBackgroundSets < ActiveRecord::Migration
  def change
  	remove_column :background_sets, :make_id
  end

end
