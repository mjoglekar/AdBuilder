class AddFieldsToAdGroup < ActiveRecord::Migration
  def change
    add_column :ad_groups, :cost, :string
    add_column :ad_groups, :term, :string
    add_column :ad_groups, :msrp, :string
    add_column :ad_groups, :optional1, :string
    add_column :ad_groups, :optional2, :string
    add_column :ad_groups, :optional3, :string
    add_column :ad_groups, :optional4, :string
    add_column :ad_groups, :optional5, :string
    add_column :ad_groups, :disclaimer, :string
    add_column :ad_groups, :rollover, :string
    add_column :ad_groups, :button, :string
  end
end
