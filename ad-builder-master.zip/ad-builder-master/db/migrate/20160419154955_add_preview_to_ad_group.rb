class AddPreviewToAdGroup < ActiveRecord::Migration
  def change
    add_attachment :ad_groups, :preview
  end
end
