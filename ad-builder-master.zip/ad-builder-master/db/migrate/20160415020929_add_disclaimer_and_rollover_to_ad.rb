class AddDisclaimerAndRolloverToAd < ActiveRecord::Migration
  def change
    add_column :ads, :disclaimer, :string
    add_column :ads, :rollover, :string
  end
end
