class CreateBackgrounds < ActiveRecord::Migration
  def change
    create_table :backgrounds do |t|
      t.string :name
      t.attachment :file
      t.integer :ad_id
      t.integer :width
      t.integer :height
      t.references :make
      t.references :background_set

      t.timestamps null: false
    end
  end
end
