class CreateMakesPromotionalLogos < ActiveRecord::Migration
  def change
    create_table :makes_promotional_logos do |t|
      t.references :make, index: true, foreign_key: true
      t.references :promotional_logo, index: true, foreign_key: true
    end
  end
end
