class CreateClientLogos < ActiveRecord::Migration
  def change
    create_table :client_logos do |t|
      t.string :name
      t.references :client
      t.attachment :file

      t.timestamps null: false
    end
  end
end
