# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20160922015651) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "ad_groups", force: :cascade do |t|
    t.integer  "client_id"
    t.integer  "template_id"
    t.integer  "make_id"
    t.datetime "created_at",                           null: false
    t.datetime "updated_at",                           null: false
    t.integer  "car_id"
    t.integer  "promotional_logo_id"
    t.string   "cost"
    t.string   "term"
    t.string   "msrp"
    t.string   "optional1"
    t.string   "optional2"
    t.string   "optional3"
    t.string   "optional4"
    t.string   "optional5"
    t.string   "disclaimer"
    t.string   "rollover"
    t.string   "button"
    t.integer  "background_set_id"
    t.string   "preview_file_name"
    t.string   "preview_content_type"
    t.integer  "preview_file_size"
    t.datetime "preview_updated_at"
    t.boolean  "is_template",          default: false
    t.string   "apr"
    t.boolean  "published",            default: false
    t.string   "trim"
  end

  add_index "ad_groups", ["background_set_id"], name: "index_ad_groups_on_background_set_id", using: :btree
  add_index "ad_groups", ["car_id"], name: "index_ad_groups_on_car_id", using: :btree
  add_index "ad_groups", ["promotional_logo_id"], name: "index_ad_groups_on_promotional_logo_id", using: :btree

  create_table "ads", force: :cascade do |t|
    t.integer  "ad_group_id"
    t.integer  "background_id"
    t.integer  "width"
    t.integer  "height"
    t.integer  "file_size"
    t.datetime "created_at",                           null: false
    t.datetime "updated_at",                           null: false
    t.string   "preview_file_name"
    t.string   "preview_content_type"
    t.integer  "preview_file_size"
    t.datetime "preview_updated_at"
    t.string   "disclaimer"
    t.string   "rollover"
    t.boolean  "show_promo_logo",      default: false
  end

  create_table "animations", force: :cascade do |t|
    t.string   "name"
    t.text     "code"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "background_sets", force: :cascade do |t|
    t.string   "name"
    t.integer  "ad_group_id"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
  end

  create_table "backgrounds", force: :cascade do |t|
    t.string   "name"
    t.string   "file_file_name"
    t.string   "file_content_type"
    t.integer  "file_file_size"
    t.datetime "file_updated_at"
    t.integer  "ad_id"
    t.integer  "width"
    t.integer  "height"
    t.integer  "make_id"
    t.integer  "background_set_id"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
    t.text     "file_meta"
  end

  create_table "buttons", force: :cascade do |t|
    t.string   "file_file_name"
    t.string   "file_content_type"
    t.integer  "file_file_size"
    t.datetime "file_updated_at"
    t.integer  "background_set_id"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
  end

  create_table "cars", force: :cascade do |t|
    t.integer  "make_id"
    t.string   "year"
    t.string   "model"
    t.string   "trim"
    t.string   "file_file_name"
    t.string   "file_content_type"
    t.integer  "file_file_size"
    t.datetime "file_updated_at"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
  end

  create_table "client_logos", force: :cascade do |t|
    t.string   "name"
    t.integer  "client_id"
    t.string   "file_file_name"
    t.string   "file_content_type"
    t.integer  "file_file_size"
    t.datetime "file_updated_at"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
  end

  create_table "client_makes", force: :cascade do |t|
    t.integer  "client_id"
    t.integer  "make_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "clients", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "element_animations", force: :cascade do |t|
    t.integer  "image_id"
    t.integer  "text_id"
    t.integer  "animation_id"
    t.string   "name"
    t.string   "start_time"
    t.string   "duration"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
  end

  create_table "frames", force: :cascade do |t|
    t.integer  "order"
    t.decimal  "length"
    t.string   "screenshot_file_name"
    t.string   "screenshot_content_type"
    t.integer  "screenshot_file_size"
    t.datetime "screenshot_updated_at"
    t.datetime "created_at",              null: false
    t.datetime "updated_at",              null: false
  end

  create_table "google_fonts", force: :cascade do |t|
    t.string   "name"
    t.string   "url"
    t.datetime "created_at",                        null: false
    t.datetime "updated_at",                        null: false
    t.string   "download_url"
    t.string   "file_file_name"
    t.string   "file_content_type"
    t.integer  "file_file_size"
    t.datetime "file_updated_at"
    t.boolean  "in_use",            default: false
  end

  create_table "images", force: :cascade do |t|
    t.integer  "ad_id"
    t.integer  "frame_id"
    t.string   "url"
    t.string   "name"
    t.decimal  "x"
    t.decimal  "y"
    t.decimal  "width"
    t.decimal  "height"
    t.integer  "z_index",             default: 200
    t.integer  "client_id"
    t.integer  "promotional_logo_id"
    t.integer  "animation_id"
    t.integer  "car_id"
    t.integer  "button_id"
    t.datetime "created_at",                          null: false
    t.datetime "updated_at",                          null: false
    t.boolean  "hidden",              default: false
  end

  create_table "makes", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "makes_background_sets", force: :cascade do |t|
    t.integer  "background_set_id"
    t.integer  "make_id"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
  end

  create_table "makes_promotional_logos", force: :cascade do |t|
    t.integer "make_id"
    t.integer "promotional_logo_id"
  end

  add_index "makes_promotional_logos", ["make_id"], name: "index_makes_promotional_logos_on_make_id", using: :btree
  add_index "makes_promotional_logos", ["promotional_logo_id"], name: "index_makes_promotional_logos_on_promotional_logo_id", using: :btree

  create_table "other_fonts", force: :cascade do |t|
    t.string   "file_file_name"
    t.string   "file_content_type"
    t.integer  "file_file_size"
    t.datetime "file_updated_at"
    t.string   "name"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
  end

  create_table "promotional_logos", force: :cascade do |t|
    t.string   "name"
    t.integer  "make_id"
    t.string   "file_file_name"
    t.string   "file_content_type"
    t.integer  "file_file_size"
    t.datetime "file_updated_at"
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
  end

  create_table "templates", force: :cascade do |t|
    t.string   "name"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "ad_group_id"
    t.integer  "make_id"
  end

  add_index "templates", ["ad_group_id"], name: "index_templates_on_ad_group_id", using: :btree
  add_index "templates", ["make_id"], name: "index_templates_on_make_id", using: :btree

  create_table "templates_makes", force: :cascade do |t|
    t.integer "template_id"
    t.integer "make_id"
  end

  add_index "templates_makes", ["make_id"], name: "index_templates_makes_on_make_id", using: :btree
  add_index "templates_makes", ["template_id"], name: "index_templates_makes_on_template_id", using: :btree

  create_table "texts", force: :cascade do |t|
    t.integer  "ad_id"
    t.integer  "frame_id"
    t.string   "file_file_name"
    t.string   "file_content_type"
    t.integer  "file_file_size"
    t.datetime "file_updated_at"
    t.string   "name"
    t.string   "content"
    t.decimal  "x"
    t.decimal  "y"
    t.decimal  "width"
    t.decimal  "height"
    t.integer  "z_index",           default: 200
    t.integer  "font_size"
    t.string   "font_family"
    t.integer  "font_weight"
    t.string   "color",             default: "#000"
    t.integer  "google_font_id"
    t.integer  "other_font_id"
    t.integer  "animation_id"
    t.datetime "created_at",                         null: false
    t.datetime "updated_at",                         null: false
    t.boolean  "italic",            default: false
    t.string   "text_align"
    t.boolean  "underline_text",    default: false
    t.boolean  "hidden",            default: false
    t.boolean  "bold"
  end

  add_foreign_key "ad_groups", "background_sets"
  add_foreign_key "ad_groups", "cars"
  add_foreign_key "ad_groups", "promotional_logos"
  add_foreign_key "makes_promotional_logos", "makes"
  add_foreign_key "makes_promotional_logos", "promotional_logos"
  add_foreign_key "templates", "ad_groups"
  add_foreign_key "templates", "makes"
  add_foreign_key "templates_makes", "makes"
  add_foreign_key "templates_makes", "templates"
end
