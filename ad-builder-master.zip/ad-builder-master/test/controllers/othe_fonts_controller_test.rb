require 'test_helper'

class OtheFontsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
