require 'test_helper'

class MakesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
