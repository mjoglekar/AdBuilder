require 'test_helper'

class GoogleFontsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
