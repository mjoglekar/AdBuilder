require 'test_helper'

class ClientControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
