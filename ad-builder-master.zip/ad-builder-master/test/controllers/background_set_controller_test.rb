require 'test_helper'

class BackgroundSetControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
