require 'test_helper'

class TemplatesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
