require 'test_helper'

class GalleriesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
