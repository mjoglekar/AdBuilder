require 'test_helper'

class PromotionalLogosControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
