require 'test_helper'

class AdGroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
