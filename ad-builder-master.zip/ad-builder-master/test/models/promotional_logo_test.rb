require 'test_helper'

class PromotionalLogoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
