require 'test_helper'

class BackgroundTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
