require 'test_helper'

class GoogleFontTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
