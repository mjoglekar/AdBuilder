require 'test_helper'

class MakesBackgroundSetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
