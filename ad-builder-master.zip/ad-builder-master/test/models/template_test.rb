require 'test_helper'

class TemplateTest < ActiveSupport::TestCase
  test "create blank" do
  	t = Template.create_blank
    # assert_equal 4, t.ads.count
  end
end
