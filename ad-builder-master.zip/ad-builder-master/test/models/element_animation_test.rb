require 'test_helper'

class ElementAnimationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
