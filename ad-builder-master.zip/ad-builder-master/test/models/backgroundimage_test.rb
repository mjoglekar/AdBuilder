require 'test_helper'

class BackgroundimageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
