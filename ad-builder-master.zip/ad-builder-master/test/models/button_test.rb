require 'test_helper'

class ButtonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
