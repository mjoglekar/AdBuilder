require 'test_helper'

class ClientManufacturerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
