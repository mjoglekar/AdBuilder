require 'test_helper'

class OtherFontTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
