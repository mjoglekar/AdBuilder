require 'open-uri'
require 'rubygems'
require 'zip'

class AdGroupsController < ApplicationController
	include ClientHelper
	def index
		# if params[:name]
		# 	@ad_groups = AdGroup.search((params[:name].present? ?  params[:name]: '*')).response.paginate(:page =>  params[:page]).order('id DESC')
		# else
			@ad_groups = AdGroup.includes(:client).where(is_template: false).order('id DESC')#.paginate(:page =>  params[:page])
		# end
		@makes = Make.all
		thread = Thread.new do
			@ad_groups.take(3).each do |ag|
				unless ag.background_set.blank? || ag.preview.exists?(:thumb)
					ad = ag.ads.find_by(width: 300)
					screenshot_path = "#{Rails.root}/public/" + ad.get_image
					ag.update(preview: File.new(screenshot_path))
				end
			end
		end
		@page = 0
	end
	
	

	def new
		@ad_group = AdGroup.new
		@ad_group.id = 999999

		@ad_group.client = Client.new
		@ad_group.car = Car.new(year: 2016)
		@make = Make.first
		@makes = Make.all
		@promotional_logo = PromotionalLogo.new
		@clients = Client.all
		@page = 1
		render 'edit'
	end

	def create
		@client = Client.find_or_create_by(name: params[:ad_group][:client][:name])
		@car = Car.find(params[:ad_group][:car][:id])
		@trim = params[:trim] == 'none' ? nil : params[:trim]
		@make = Make.find(params[:make])
		@promotional_logo = params[:promotional_logo].blank? || params[:promotional_logo].downcase == 'none' || params[:promotional_logo] == '0' ? nil : PromotionalLogo.find(params[:promotional_logo])
		@background_set = @make.background_sets.first
		@ad_group = AdGroup.new

		@ad_group.update(make: @make, car: @car, trim: @trim, client: @client, rollover: params[:ad_group][:rollover])
		@ad_group.update(promotional_logo: @promotional_logo) if @promotional_logo

		AdGroup.fields.each do |field|
			puts params[:ad_group][field]
			@ad_group[field] = params[:ad_group][field]
		end

		template = @make.templates.count > 0 ? @make.templates.last : Template.last
		@ad_group.apply_template(template)
		@ad_group.adjust_for_promotional_logo unless @promotional_logo
		@ad_group.save

		redirect_to action: "choose_background", id: @ad_group.id
	end

	def edit
		@ad_group = AdGroup.find_by_id(params[:id])
		@make = @ad_group.make
		@makes = Make.all
		@car = @ad_group.car.blank? ? Car.new(year: 2016, make: Make.first, model: Make.first.models.first) : @ad_group.car
		@model = @ad_group.car.model
		@trim = @ad_group.trim ? @ad_group.trim : 'none'
		@cars = Car.all
		@models = @car.make.cars.pluck(:model).uniq
		@trims = Car.where(make: @car.make, model: @car.model).pluck(:trim, :trim).uniq
		@promotional_logo = @ad_group.promotional_logo || PromotionalLogo.new
		@promotional_logos = @make.promotional_logos.all
		@page = 1
		render 'edit'
	end

	def edit_as_new
		@ad_group = AdGroup.find_by_id(params[:id])
		new_ad_group = @ad_group.amoeba_dup
		new_ad_group.published = false
		new_ad_group.save
		redirect_to edit_ad_group_path(new_ad_group)
	end

	def update
		@ad_group = AdGroup.find_by_id(params[:id])
		@client = Client.find_or_create_by(name: params[:ad_group][:client][:name])
		@make = Make.find(params[:make])
		if @make.id != @ad_group.make_id
			@ad_group.update(background_set: nil)
			@ad_group.ads.each do |ad|
				ad.update(background: nil)
			end
		end
		@car = Car.find(params[:ad_group][:car][:id])
		@trim = params[:trim] == 'none' ? nil : params[:trim]
		@promotional_logo = params[:promotional_logo].blank? || params[:promotional_logo].downcase == 'none' || params[:promotional_logo] == '0' ? nil : PromotionalLogo.find(params[:promotional_logo])
		if (@promotional_logo && @ad_group.promotional_logo.nil?) || (@promotional_logo.nil? && @ad_group.promotional_logo)
			@ad_group.promotional_logo = @promotional_logo
			@ad_group.adjust_for_promotional_logo
		end
		@ad_group.update_attributes(make: @make, car: @car, trim: @trim, client: @client, rollover: params[:ad_group][:rollover], promotional_logo: @promotional_logo || nil)
		AdGroup.fields.each do |field|
			@ad_group[field] = params[:ad_group][field]
		end

		@ad_group.ads.each do |ad|
			url = @ad_group.car.file.blank? ? nil : @ad_group.car.file.url
			car = @ad_group.car.file.blank? ? nil : @ad_group.car
			ad.images.find_by(name: 'car').update(url: url, car: car)

			url = @ad_group.promotional_logo.blank? ? nil : @ad_group.promotional_logo.file.url
			logo = @ad_group.promotional_logo.blank? ? nil : @ad_group.promotional_logo
	 		ad.images.find_by(name: "promotional_logo").update(url: url, promotional_logo: logo)

	 		ad.texts.find_by(name: "client_name").update(content: @client.name)

	 		if @ad_group.car.blank?
		 		car_name = ''
		 	else
		 		car_name = "#{@car.year} #{@make.name} #{@car.model}"
		 		car_name += " #{@car.trim}" unless params[:trim] == 'none' || params[:trim].blank?
		 	end
	 		ad.texts.find_by(name: "car_name").update(content: car_name)

			AdGroup.fields.each do |field|
				if ad.texts.find_by(name: field)
					text = ad.texts.find_by(name: field)
					text.update_attributes(content: params[:ad_group][field])
					text.save
				else
					ad.texts << Text.new(name: field, content: params[:ad_group][field])
				end
			end

		end
		template = @make.templates.count > 0 ? @make.templates.last : Template.last
		@ad_group.apply_template(template) if @ad_group.new_record?

		@ad_group.save
		redirect_to action: "choose_background", id: @ad_group.id
	end

	def destroy
		@ad_group = AdGroup.find(params[:id])
		@ad_group.destroy
		redirect_to ad_groups_path
	end

	def choose_background
		@ad_group = AdGroup.find_by_id(params[:id])
		unless @ad_group
			redirect_to new_ad_group_path
			return
		end
		unless @ad_group.template
			template = @ad_group.make.templates.count > 0 ? @ad_group.make.templates.last : Template.last
			@ad_group.apply_template(template) 
		end
		if @ad_group.make.nil?
			flash[:notice] = "You must select a make"
			redirect_to edit_ad_group_path(@ad_group)
		else
			make = @ad_group.make
			if @ad_group.background_set.blank?
				@ad_group.background_set = make.background_sets.count > 0 ? make.background_sets.last : BackgroundSet.first
			end
			@backgrounds = []
			@ad_group.make.background_sets.each do |background_set|
				background = background_set.backgrounds.find_by(width: 300)
				@backgrounds << background unless background.nil?
			end
			@templates = make.templates.limit(2)
			remaining = 2 - @templates.length
			@templates += Template.all.reverse[0..remaining - 1] unless remaining == 0
			@page = 2
		end
	end

	def update_background
		@ad_group = AdGroup.find(params[:id])
		@template = Template.find(params[:ad_group][:template][:id])
		@background_set = BackgroundSet.find_by_id(params[:ad_group][:background_set][:id])
		@ad_group.apply_template(@template) unless @ad_group.template == @template && @ad_group.ads.count == 4
		@ad_group.update_background(@background_set) unless @background_set.blank?

		if @ad_group.save
			redirect_to @ad_group
		else
			throw error
		end
	end

	def show
		@ad_group = AdGroup.find_by_id(params[:id])
		if @ad_group.blank?
			redirect_to new_ad_group_path
			return
		elsif @ad_group.background_set.blank?
			redirect_to choose_background_path
			return
		end
		missing_background = false
		@ad_group.ads.each do |ad|
			missing_background = true if ad.background.nil?
		end
		if missing_background
			flash[:notice] = "Select a background"
			redirect_to choose_background_path
		else
			@google_fonts = GoogleFont.where(in_use: true).order(:name)
			@other_fonts = OtherFont.order(:name)
			@fonts = @google_fonts + @other_fonts
			@animations = Animation.all
			@page = 3

			Thread.new do
				@ad_group.render_all_other_fonts
			end

			render template: '/ad_groups/show', locals: {ad_group: @ad_group}, layout: true
		end
	end

	def preview
		@ad_group = AdGroup.find(params[:id])
		@template = @ad_group
		render partial: 'preview', locals: { ad_group: @ad_group, template: @template }
	end

	def save_as_template
		@ad_group = AdGroup.find(params[:id])

		template = @ad_group.make_template # see AdGroup model
		params[:makes].each do |make_id|
			@make = Make.find_by(id: make_id)
			@make.templates << template
		end
		redirect_to ad_groups_path
	end

	def get_jpegs
		tmp_dir = File.join(Dir::tmpdir, "jpegs")
		FileUtils.remove_dir(tmp_dir) if Dir.exists?(tmp_dir)
		Dir.mkdir(tmp_dir)

		@ad_group = AdGroup.find(params[:id])
		@ad_group.ads.each do |ad|
			css = ad.get_fonts_css
			html = (render_to_string partial: '/ads/preview', locals: {ad: ad, css: css, publish: false}, layout: false)
			kit = IMGKit.new(html, :quality => 100)
			file = kit.to_file(tmp_dir + '/file.png')
			image = MiniMagick::Image.new(file.path)
			image.crop("#{ad.width}x#{ad.height}+0+0")
			send_file tmp_dir + '/file.png'
		end
	end

	def finalize
		@ad_group = AdGroup.find_by_id(params[:id])
		
		Thread.new do
			require 'open-uri'
			if Rails.env.development?
				puts "pinging http://localhost:4000 node horseman"
				response = open("http://localhost:4000").read
				puts "pinging http://localhost:8891 manet"
				response2 = open("http://localhost:8891").read
			else
				puts "pinging node horseman service"
				response = open("https://stormy-ocean-64852.herokuapp.com").read
				puts "pinging manet service"
				response2 = open("https://calm-headland-96359.herokuapp.com").read
			end
		end

		Thread.new do
			@ad_group.render_all_other_fonts
		end

		if @ad_group.blank?
			redirect_to new_ad_group_path
			return
		elsif @ad_group.background_set.blank?
			redirect_to choose_background_path
			return
		end
		@page = 4
		render 'publish'
	end

	def publish
		@ad_group = AdGroup.includes(:car, :client, ads: [:images, :texts, :background, :element_animations]).find(params[:id])
		date = Date.today.strftime("%b%y")
		car = @ad_group.car.make.name + @ad_group.car.model || "Branded"
		tmp_dir = File.join(Dir::tmpdir, "ad_#{@ad_group.id}")
		ad_names = []

		FileUtils.remove_dir(tmp_dir) if Dir.exists?(tmp_dir)
		
		Dir.mkdir(tmp_dir)

		screenshots = {}

		client = @ad_group.client.name
		ad_group_name = "#{client}_#{date}_#{car}".gsub(/\W/, '')

		threads = []
		@ad_group.ads.each do |ad|
			threads << Thread.new do
				ad_dimensions = "#{ad.width}x#{ad.height}"
				ad_name = "#{ad_group_name}_#{ad_dimensions}"
				ad_dir = tmp_dir + '/'+ ad_name
				ad_names << ad_name + '.zip'
				FileUtils.remove_dir(ad_dir) if Dir.exists?(ad_dir)
				FileUtils.remove_dir(ad_dir + '/images') if Dir.exists?(ad_dir + '/images')
				Dir.mkdir(ad_dir)
				Dir.mkdir(ad_dir + '/images')

				input_filenames = []
				ad.images.each do |image|
					next if image.url.nil? || (@ad_group.promotional_logo.nil? && image.name == 'promotional_logo')
					dimensions = "#{image.width*1.5}" unless image.width.nil?
					image_name = image.name + '.png'
					image_path = ad_dir + '/images/' + image_name
					IO.copy_stream(open(image.url), image_path)
					image = MiniMagick::Image.new(image_path)
					dimensions = "#{image.width}" if dimensions == "" || dimensions.nil?
					image.adaptive_resize(dimensions)

					input_filenames << image_name
				end

				ad.texts.where.not(other_font: nil).each do |text|
					image_name = 'text' + text.id.to_s + '.png'
					image_path = ad_dir + '/images/' + image_name
					input_filenames << image_name
					unless text.file.exists?
						if Rails.env.development?
							url = "http://localhost:3000/" + text.get_image # "../../" + 
						else
							url = "https://ad-builder.herokuapp.com/" + text.get_image
						end
					else
						if Rails.env.development?
							url = "http://localhost:3000/" + text.file.url
						else
							url = "https://ad-builder.herokuapp.com/" + text.file.url
						end
					end
					IO.copy_stream(open(url), image_path)
				end
				
				background_name = ad.background.file_file_name
				background_path = ad_dir + '/images/' + background_name
				IO.copy_stream(open(ad.background.file.url), background_path)
				input_filenames << background_name

				html = (render_to_string partial: '/ads/preview', locals: {ad: ad, static: false, publish: true}, layout: false)
				css = 'body {margin:0;padding:0;} div.ad {box-sizing: border-box;-moz-box-sizing: border-box;-webkit-box-sizing: border-box; border:1px solid black;display:inline-block;position:relative;top:0px;left:0px;}div.ad img, div.ad .text {position: absolute}'

				screenshot_path = "#{Rails.root}/public/" + ad.get_image #tmp_dir + "/" + dimensions + '.png'
				screenshots[ad_name] = screenshot_path
				@ad_group.update(preview: File.new(screenshot_path), published: true) if ad.width == 300

				Zip::File.open("#{ad_dir}.zip", Zip::File::CREATE) do |zipfile|
				  input_filenames.uniq.each do |filename|
				    # Two arguments:
				    # - The name of the file as it will appear in the archive
				    # - The original file, including the path to find it
				    zipfile.add(filename, ad_dir + '/images/' + filename)
				  end
				  zipfile.get_output_stream("index.html") { |os| os.write html }
				  zipfile.get_output_stream("index.css") { |os| os.write css }
				end
			end
		end

		threads.each(&:join)

		Zip::File.open("#{tmp_dir}/#{ad_group_name}.zip", Zip::File::CREATE) do |zipfile|
	  	screenshots.each do |name, path|
				zipfile.add(name + '.png', path)
  		end
		  ad_names.each do |filename|
		    zipfile.add(filename, tmp_dir + '/' + filename)
		  end
		end
		send_file "#{tmp_dir}/#{ad_group_name}.zip", type: 'application/zip'
	end
end
