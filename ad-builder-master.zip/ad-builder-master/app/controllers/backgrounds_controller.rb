class BackgroundsController < ApplicationController

  def index
    @backgrounds = Background.all
    puts "========"
    p @backgrounds
    puts "+++++++++++++++++"
    render :'backgrounds/index'
  end

  def new
     @background = Background.new
    render :'backgrounds/new'
  end

  def create
    @background = Background.new(params[:background_params])
      if @background.save
        "++++++++++++"
        redirect_to background_path
      else
        render :'backgrounds/new'
        @errors = @background.errors.full_messages
      end
  end

  def show
    @background = Background.find(params[:id])
    render :'backgrounds/show'
  end

  def destroy
    @background = Background.find(params[:id])
    @background.destroy
    redirect_to backend_path
  end

  # def edit
  #   @background = Background.find(params[:id])
  #   render :'backgrounds/edit'
  # end

  # def update
  # end


  private 

  def background_params
    params.require(:background).permit(:name,:file,:make_id)
  end


end
