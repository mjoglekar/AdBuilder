class OtherFontsController < ApplicationController

	def index
		@other_fonts = OtherFont.all
		render :'other_fonts/index'
	end
	
	def new
		@other_font = OtherFont.new
		render :'other_fonts/new'
	end

	def create
		@new_font = OtherFont.new(font_params)
		@new_font.name = @new_font.file_file_name.split('.')[0]
		if @new_font.save
			flash[:notice] = "Font successfully saved"
			redirect_to "/backend/fonts"
		else
			flash[:notice] = "Something went wrong"
			render :'/backend/fonts'
		end
	end

	def show
		@font = OtherFont.find(params[:id])
		@texts = Text.all
		render :'other_fonts/show'
	end

	def destroy
		@font = OtherFont.find(params[:id])
		@font.destroy
		redirect_to backend_fonts_path
	end

	private

	def font_params
		params.require(:other_font).permit(:name,:file)
	end

end
