class CarsController < ApplicationController

	def index
		@cars = Car.where(year: params[:year], model: params[:model]).order(:model)
		render "_index.html.erb", layout: false
	end

	def new
		@makes = Make.all
	end

	def create
		@make = Make.find(params[:make])
		unless params[:files].blank?
			params[:files].each do |file|
				@car = Car.new(car_params)
				@car.file = file
				@car.make = @make
				@car.save
			end
		else
			@car = Car.new(car_params)
			@car.make = @make
			@car.save
		end

		redirect_to "/backend/cars"
	end



	def show
		@car = Car.find(params[:id])
	end

	def show_all
		if params[:trim].downcase == 'none'
			@cars = Car.where(year: params[:year], model: params[:model]).order(:model)
		else
			@cars = Car.where(car_params).order(:trim)
		end
		puts "--------------------------"
		p @cars
		puts "--------------------------"
		render "_show_all.html.haml", layout: false
	end

	def get_models
		@make = Make.find(params["make"])
		@models = Car.where(make: @make, year: params["year"]).map { |m| m.model }
		respond_to do |format|
      format.html
      format.json { render json: @models.uniq }
    end
	end

	def get_trims
		@make = Make.find(params[:make])
		@trims = Car.where(make: @make, year: params[:year], model: params[:model]).map { |m| m.trim }
		respond_to do |format|
      format.html
      format.json { render json: @trims.uniq }
    end
	end

	def backend
		@makes = Make.all
	end

	def destroy
    @car = Car.find(params[:id])
    begin
    	@car.destroy
    rescue ActiveRecord::RecordNotFound
    	render :json => "Can't delete this car"
    	flash[:notice] = "Can't delete this car"
 	 	rescue
 	 	end
    #Only comes in here if nothing else catches the error
     redirect_to backend_cars_path
  end

	private

	def car_params
	  params.permit(:year,:model,:trim)
	end
end
