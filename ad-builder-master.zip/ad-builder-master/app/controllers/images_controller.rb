class ImagesController < ApplicationController
	def index
		@image = Image.new
	end

	def create
	  @image = Image.create( image_params )
	  redirect_to @image
	end

	def show
		@image = Image.find(params[:id])
		render component: 'Image', props: { url: @image.file }
	end

	def update
		@image = Image.find(params[:id])
		# ["x","y","height","width"].each do |attribute|
		# 	@image[attribute] = params[attribute]
		# end
		@image.update(image_params)

		@image.save!

		respond_to do |format|  ## Add this
	    format.json { render json: {}, status: :ok}
	  end
	end

	def update_animation
		@image = Image.find(params[:image_id])
		@animation = Animation.find_by(name: params[:animation])
		if @image.element_animation.nil?
			ElementAnimation.create(image: @image, animation: @animation, name: @animation.name, duration: params[:duration], start_time: params[:start_time])
		else
			@image.element_animation.update(animation: @animation, name: @animation.name, duration: params[:duration], start_time: params[:start_time])
		end

		respond_to do |format|  ## Add this
	    format.json { render json: {}, status: :ok}
	  end
	end

	private

	# Use strong_parameters for attribute whitelisting
	# Be sure to update your create() and update() controller methods.

	def image_params
	  params.permit(:file,:x,:y,:height,:width,:animation,:duration,:start_time,:z_index,:hidden)
	end
end
