class ClientsController < ApplicationController

	def index
		@clients = Client.all
  	if params[:search]
   	 	@clients = Client.search(params[:search]).order("id DESC")
   	 	puts "========"
   	 	p @clients
   	 	puts "++++++++++++++++"
  	else
    	@clients = Client.all.order('id DESC')
  	end
	end

	def show
	 @client = Client.find(params[:id])
	end

end
