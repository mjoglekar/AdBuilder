class MakesController < ApplicationController

	def index
		@makes = Make.all
		render partial: "/makes/index", locals: {make: @makes}, layout: false
	end
	def new
		@make = Make.new
	end

	def create
		Make.create(name: params[:make][:name]) unless params[:make][:name].blank?
		redirect_to '/backend'
	end
end
