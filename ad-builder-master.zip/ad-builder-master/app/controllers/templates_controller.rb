class TemplatesController < ApplicationController
	def index
		@make = Make.find(params[:make_id])
		@ad_group = @make.ad_groups.where(is_template: false).last
		@templates = @make.templates
		render :index, layout: false
	end

	def destroy
		@make = Make.find(params[:format])
		@template = Template.find(params[:id])
    return unless @make && @template
    @make.templates.destroy(@template)
    redirect_to backend_templates_path
	end

	def backend
		@makes = Make.all
	end
end
