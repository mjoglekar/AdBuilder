class TextsController < ApplicationController
	def create
		@text = Text.create(text_params)
		@text.element_animations << ElementAnimation.create
		redirect_to @text
	end

	def show
		@text = Text.includes(:other_font, :google_font).find(params[:id])
		render partial: 'show', locals: {text: @text, static: true, publish: false}, layout: false
	end

	def get_image
		@text = Text.find(params[:id])
		@image = "../../" + @text.get_image
		render 'get_image'
	end

	def update
		@text = Text.find(params[:id])
		@text.update(text_params)
		Thread.new do
			@text.get_image if !@text.other_font.blank?
		end
		@text.save!

		respond_to do |format|
	    format.json { render json: {}, status: :ok}
	  end
	end

	def update_animation
		@text = Text.find(params[:text_id])
		@animation = Animation.find_by(name: params[:animation])
		if @text.element_animation.nil?
			ElementAnimation.create(text: @text, animation: @animation, name: params[:animation], duration: params[:duration], start_time: params[:start_time])
		else
			@text.element_animation.update(animation: @animation, name: @animation.name, duration: params[:duration], start_time: params[:start_time])
		end

		respond_to do |format|  ## Add this
	    format.json { render json: {}, status: :ok}
	  end
	end

	private

	def text_params
    params.permit(:id,:text_id,:content,:x,:y,:height,:width,:google_font_id,:other_font_id,:font_family,:font_size,:color,:animation,:duration,:start_time,:text_align,:z_index,:hidden,:bold,:italic,:underline_text)
  end
end
