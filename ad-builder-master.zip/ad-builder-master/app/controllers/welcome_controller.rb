class WelcomeController < ApplicationController
	def index
		render 'index', layout: false
	end

	def backend
		render 'backend'
	end

  def templates
    @makes = Make.order('name')
    render 'welcome/backend/templates'
  end

  def fonts
    @other_font = OtherFont.new
    @other_fonts = OtherFont.order('name')
    @google_fonts = GoogleFont.order('name')
    render 'welcome/fonts'
  end
end
