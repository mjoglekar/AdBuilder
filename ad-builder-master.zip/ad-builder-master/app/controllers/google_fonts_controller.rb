class GoogleFontsController < ApplicationController

  def index
    @fonts = GoogleFont.order('name')
    render :'google_fonts/index'
  end

  def new
  	@google_font = GoogleFont.new
  		# respond_to do |format|
  		# 	format.html # new.html.erb
    #   	format.json { render json: @google_font}
    #   	format.js
  		render :'google_fonts/new'
  	# end
  end

  def create
  	@font = GoogleFont.new(font_params)
  	respond_to do |format|
  		if @font.save
  			# format.html{redirect_to @font, "Font was succesfully added"}
  			 format.json { render json: @font}
      	# format.js
  		# redirect_to google_fonts_path
  		else
	  		@errors = @font.errors.full_messages
	  	  render :'google_fonts/new'
	  	 end
  	end
  end

  # def edit
  # end

  def update
  @google_font = GoogleFont.find(params[:id])
  @google_font.update_attributes(font_params)
  if @google_font.save
    respond_to do |format|  ## Add this
    format.json { render json: {}, status: :ok}
    end
  else
     render :text => "Not able to save", :status => 404
  end
end
  
  private

  def font_params
  	params.permit(:in_use,:id)
  end


end
