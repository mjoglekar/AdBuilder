class PromotionalLogosController < ApplicationController

	def index
		@make = Make.find(params[:make_id])
		@promotional_logos = @make.promotional_logos#.map{|p| [p.name, p.id]}.to_h
		respond_to do |format|
      format.html { render :'promotional_logos/index', layout: false }
      format.json { render json: @promotional_logos }
    end
	end

	def new
		@promotional_logo = PromotionalLogo.new
		@makes = Make.all
	end

	def create
		if params[:makes]
			@promotional_logo = PromotionalLogo.create(name: params[:name], file: params[:file])
			params[:makes].each do |id|
				@make = Make.find(id)
				@make.promotional_logos << @promotional_logo
			end
			notice = "The promotional logo was added successfully"
		else
			notice = "Please select at least one make"
		end
		flash[:notice]
		redirect_to backend_path
	end

	def show
		@promotional_logo = PromotionalLogo.find(params[:id])
		respond_to do |format|
      format.html { render '_show.html.haml', layout: false }
      format.json { render json: @promotional_logo }
    end
	end

	def get_all
		@promotional_logo = PromotionalLogo.where(make_id: params[:id])
		respond_to do |format|
      format.html
      format.json { render json: @promotional_logo }
    end
	end

	def destroy
    @make = Make.find(params[:format])
		@promotional_logo = PromotionalLogo.find(params[:id])
    return unless @make && @promotional_logo
    @make.promotional_logos.destroy(@promotional_logo)
    redirect_to backend_promotional_logos_path
	end

	def backend
		@makes = Make.all
	end
end
