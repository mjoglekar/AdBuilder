class AdsController < ApplicationController

	def show
		@ad = Ad.includes(:images, :texts, :background, :element_animations).find(params[:id])
		static = params[:static] == 'true'
		render partial: 'preview', locals: {ad: @ad, static: static, publish: false}, layout: false
	end

	def update
		@ad = Ad.find(params[:id])
		@ad.update(show_promo_logo: params[:show_promo_logo]) if params[:show_promo_logo]
		@ad.save
		head :no_content
	end

	def get_image
		tmp_dir = File.join(Dir::tmpdir, "jpeg")
		FileUtils.remove_dir(tmp_dir) if Dir.exists?(tmp_dir)
		Dir.mkdir(tmp_dir)

		ad = Ad.find(params[:id])
		
		data = {link: ad.get_image} # see Ad model
		render json: data
	end

	def get_fonts_css(ad)
		css = ""
		ad.texts.where.not(google_font_id: nil).each do |text|
			url = download_font(text.google_font)
			css += "@font-face { font-family: '#{text.font_family}'; font-weight: 400; font-style: normal; src: url('../#{url}') format('truetype'); } "
		end
		return css
	end

	# def download_font(google_font)
	# 	require 'net/http'
	# 	require 'tempfile'
	# 	require 'uri'

	# 	file_url = "#{Dir::tmpdir}/#{google_font.name.gsub(' ', '_')}.ttf"

	# 	puts "downloading font ++++++++++++++++++++++++"
	# 	resp = Net::HTTP.get_response(URI.parse(google_font.download_url))
	# 	file = File.open(file_url, 'wb' ) do |output|
	#     output.write resp.body
	# 		google_font.update(file: output)
	#   end

	# 	return google_font.file.url #"http://localhost:3000/" + 
	# end
	
end
