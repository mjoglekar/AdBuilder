class BackgroundSetsController < ApplicationController
  include BackgroundSetHelper
  def index
    @make = Make.find(params[:make_id])
    @backgrounds = preview_backgrounds(@make)
    puts "here -----------------------------"
    render :'background_sets/index', layout: false
  end

  def new
    @background_set = BackgroundSet.new
    @makes = Make.all
    render :'background_sets/new'
  end

  def create
    @background_set = BackgroundSet.new(name: params[:name])
    @background_set.button = Button.create(background_set: @background_set, file: params[:file])
    if params[:files] #background images
      params[:files].each do |file|
        @background_set.backgrounds.new(file: file)
      end
    end
    @background_set.backgrounds.each do |background|
      background.update_attributes(width: background.file.width, height: background.file.height)
    end
      missing = missing_assets(@background_set)
      if missing 
        flash[:notice] = "These are the sizes that you are missing #{missing}."
        redirect_to new_background_set_path
      else
        params[:makes].each do |make_id|
          @make = Make.find(make_id)
          @make.background_sets << @background_set
        end
        if @background_set.save
          flash[:notice] = "Background Set successfully uploaded"
          redirect_to "/backend/backgrounds"
        end 
      end
   
  end

  def show
   @background_set = BackgroundSet.find(params[:id])
   render :'background_sets/show'
  end

  def destroy
    @background_set = BackgroundSet.find(params[:id])
    @make = Make.find(params[:format])
    return unless @make && @background_set
    @make.background_sets.destroy(@background_set)
    redirect_to backend_backgrounds_path
  end

  def backend
    @background_set = BackgroundSet.new
    @makes = Make.all
  end

  private
  def background_params
   params.require(:background_set).permit(:name,:image,:background_image_id, :makes)
  end
end