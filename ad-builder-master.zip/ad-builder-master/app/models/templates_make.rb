class TemplatesMake < ActiveRecord::Base
	belongs_to :template
	belongs_to :make
end
