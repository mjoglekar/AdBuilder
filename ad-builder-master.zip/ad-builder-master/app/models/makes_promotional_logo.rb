class MakesPromotionalLogo < ActiveRecord::Base
	belongs_to :make
	belongs_to :promotional_logo
end