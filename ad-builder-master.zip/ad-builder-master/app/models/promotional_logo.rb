class PromotionalLogo < ActiveRecord::Base
  validates :name, presence: true
  has_many :makes
  has_attached_file :file, default_url: "/promotional_logos/:style/missing.png"
  validates_attachment_content_type :file, content_type: /\Aimage\/.*\Z/
  has_attached_file :file,
                    :storage => :s3,
                    :path => "promotional_logos/:id/:style_:extension",
                    :s3_credentials => Proc.new{|a| a.instance.s3_credentials }
  def s3_credentials
    {:bucket => ENV['bucket'], :access_key_id => ENV['access_key_id'], :secret_access_key => ENV['secret_access_key']}
  end
end
