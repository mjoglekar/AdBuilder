class Animation < ActiveRecord::Base
end
