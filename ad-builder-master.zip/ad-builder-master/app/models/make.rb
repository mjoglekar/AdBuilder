class Make < ActiveRecord::Base

	validates :name, :uniqueness => true
	has_many :makes_background_sets
  has_many :background_sets, through: :makes_background_sets
  has_many :templates_makes
  has_many :templates, through: :templates_makes
  has_many :promotional_logos
  has_many :cars
  has_many :ad_groups
  default_scope { order('name ASC') }
end
