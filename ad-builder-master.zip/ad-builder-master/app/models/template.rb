class Template < ActiveRecord::Base
	belongs_to :ad_group, dependent: :destroy
	has_many :templates_makes, dependent: :destroy
	has_many :makes, through: :templates_makes

	def preview_with(ad_group)
		puts ",,,,,,,,,,,,,,,,,,,, preview with ,,,,,,,,,,,,,,,,,,,,,"
		t_ad = self.ad_group.ads.find_by(width: 300)
		ad = ad_group.ads.find_by(width: 300)

		ad.images.each do |image|
			t_image = image.get_corresponding_image(t_ad)
		end
		ad.texts.each do |text|
			t_text = text.get_corresponding_text(t_ad)
			t_text.content = text.content
		end
		t_ad.background = ad.background
		return t_ad
	end

	def self.create_blank
		blank_ad_group = AdGroup.create(is_template: true)
		Ad.sizes.each do |size|
			blank_ad = Ad.create(width: size[0], height: size[1])
			AdGroup.fields.each do |field|
				blank_ad.texts << Text.create(name: field)
			end
			blank_ad.texts << Text.create(name: 'client_name')
			blank_ad.texts << Text.create(name: 'car_name')
			AdGroup.image_fields.each do |image_field|
				blank_ad.images << Image.create(name: image_field)
			end
			blank_ad.save
			puts "|||||||||||||||||||||||||||||||||||||||"
			blank_ad_group.ads << blank_ad
			puts "|||||||||||||||||||||||||||||||||||||||"
			blank_ad_group.save
		end

		blank_template = Template.create(ad_group: blank_ad_group)
		blank_template.ad_group.update(template: blank_template)
		blank_template.save
	end
end
