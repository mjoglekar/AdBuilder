class Frame < ActiveRecord::Base
	has_many :images
	has_many :texts
end
