class BackgroundSet < ActiveRecord::Base
	has_many :makes_background_sets
  has_many :makes, through: :makes_background_sets
  has_many :backgrounds,:dependent => :destroy
  has_one :button
  has_many :ad_groups
end
