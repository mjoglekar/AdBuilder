class AdGroup < ActiveRecord::Base
	has_many :ads, dependent: :destroy, counter_cache:true
	belongs_to :make
	# validates :make,presence: true
	belongs_to :client
	# validates :client, presence: true
	belongs_to :car
	# validates :car, presence: true
	belongs_to :promotional_logo
	belongs_to :template
	belongs_to :background_set
	has_one	:button, through: :background_set

	if Rails.env.development?
		has_attached_file :preview,
											:path => "public/ad_groups/:id/:style_:extension",
	                    :url => "ad_groups/:id/:style_:extension",
	                    :styles => { :thumb => "180x150" },
	                    :convert_options => { :thumb => "-quality 75 -strip" }
  else
		has_attached_file :preview,
	                    :storage => :s3,
	                    :path => "public/ad_groups/:id/:style_:extension",
	                    :url => "ad_groups/:id/:style_:extension",
	                    :styles => { :thumb => "180x150" },
	                    :convert_options => { :thumb => "-quality 75 -strip" },
	                    :s3_credentials => Proc.new{|a| a.instance.s3_credentials }
  end
  
  validates_attachment_content_type :preview, content_type: /\Aimage\/.*\Z/

  before_save 'self.template = Template.first if self.template.nil?'

  def s3_credentials
    {:bucket => ENV['bucket'], :access_key_id => ENV['access_key_id'], :secret_access_key => ENV['secret_access_key']}
  end   

	# default_scope { order('updated_at DESC') }

	self.per_page = 50
	WillPaginate.per_page = 50

	amoeba do
    include_association :ads
  end

	def self.fields
		%w(cost term apr msrp optional1 optional2 optional3 optional4 optional5 disclaimer)
  end

  def self.image_fields
		%w(car button promotional_logo)
  end

  # def self.non_branded_remove
  # 	%w(optional2 optional3 optional4)
  # end

  def get_preview
  	ad = self.ads.find_by(width: 300)
  	return if ad.background.nil?
  	img_url = ad.get_image
  	self.update(preview: File.new("#{Rails.root}/#{img_url}"))
  end

  def render_all_other_fonts
  	self.ads.each do |ad|
  		ad.texts.where.not(other_font: nil).each do |text|
  			text.get_image unless text.file.exists?
  		end
  	end
  end

  def car_name
  	has_trim = !self.trim.blank?
  	return self.car.name({trim: has_trim})
  end

	def make_template
		puts "before"
		puts self.ads.count

		ad_group = self.amoeba_dup

		puts "after dup"
		puts ad_group.ads.count

		ad_group.clear_content

		puts "after clear"
		puts ad_group.ads.count

		template = Template.create(ad_group: ad_group)
		ad_group.update(template_id: template.id, is_template: true)
		return template
	end

	def clear_content
		ad_group = self
		ad_group[:rollover] = ""
		ad_group.background_set = nil
		ad_group.preview = nil
		AdGroup.fields.each do |field|
			ad_group[field] = ""
		end
		ad_group.ads.each do |ad|
			ad.preview = nil
			ad.background = nil
			ad.texts.each do |text|
				text.update(content: "")
			end
			ad.images.each do |image|
				image.update(car: nil, button: nil, promotional_logo: nil, url: nil)
				image.save
			end
			ad.save
		end
		
		ad_group.save
	end

	def update_background(background_set)
		ad_group = self
		p ad_group.id
		ad_group.update(background_set: background_set)

		background_set.backgrounds.each do |background|
			ad = nil
			Ad.uncached do
				ad = ad_group.ads.find_by(width: background.width)
			end
			# if ad.nil?
			# 	ad = Ad.create(width: background.width, height: background.height,background: background)
			# 	ad_group.ads << ad
			# else
			puts "updating ad background"
			ad.update(background: background)
			ad.save

		
			button = ad.images.find_by(name: "button")
			button.update(button: background_set.button, url: background_set.button.file.url)
			button.save
		end

		self.save
	end

	def apply_template(template)
		ad_group = self
		ad_group.ads.each do |ad|
			ad.destroy
			puts "here"
		end
		puts "======================== apply template ============================"
		template.ad_group.ads.each do |ad|
			puts "======================== inside template dup ============================"
			new_ad = ad.amoeba_dup
			new_ad.background = nil
			new_ad.save
			new_ad.texts.each do |text|
				content = ad_group[text.name]
				text.update(content: content)
			end
			new_ad.texts.find_by(name: 'client_name').update(content: ad_group.client.name)
			new_ad.texts.find_by(name: 'car_name').update(content: ad_group.car_name)

			if ad_group.car.file_file_name.blank?
				url = nil
			else
				url = ad_group.car.file.url
			end
			new_ad.images.find_by(name: 'car').update(url: url)

			new_ad.images.find_by(name: 'promotional_logo').update(url: ad_group.promotional_logo.file.url) unless ad_group.promotional_logo.blank?
			ad_group.ads << new_ad
			# new_ad.images.each do |image|
			# 	url = ad_group[image.name].file.url
			# 	image.update(url: url)
			# end
		end
		ad_group.update(template: template, is_template: false)
		ad_group.save
	end

	def adjust_for_promotional_logo
		puts "***********************************************************"
		puts "adjust_for_promotional_logo"
		adjustment = self.promotional_logo ? 3 : -3
		puts "Adjustment: #{adjustment}"
		self.ads.each do |ad|
			ad.texts.each do |text|
				if text.element_animation
					start = text.element_animation.start_time.to_i
					text.element_animation.update(start_time: (start + adjustment).to_s + 's')
					text.element_animation.save
				end
			end
			ad.images.each do |image|
				next if image.name == 'promotional_logo'
				if image.element_animation
					start = image.element_animation.start_time.to_i
					image.element_animation.update(start_time: (start + adjustment).to_s + 's')
					image.element_animation.save
				end
			end
		end
		puts "***********************************************************"

	end

end
