class Client < ActiveRecord::Base
	validates :name, presence: true

	def self.search(search)
		search = "%#{search}%"
		Client.where("name LIKE ?", search)
	end

end

