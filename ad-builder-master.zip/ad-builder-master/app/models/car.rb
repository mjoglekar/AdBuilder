class Car < ActiveRecord::Base
	has_attached_file :file, default_url: "/images/:style/missing.png"
  validates_attachment_content_type :file, content_type: /\Aimage\/.*\Z/
  has_attached_file :file,
                    :storage => :s3,
                    :path => "cars/:year/:make/:model/:trim/:id/:style_:extension",
                    :s3_credentials => Proc.new{|a| a.instance.s3_credentials }
  validates :make, :model, :year, presence: true                  

  belongs_to :make

  def s3_credentials
    {:bucket => ENV['bucket'], :access_key_id => ENV['access_key_id'], :secret_access_key => ENV['secret_access_key']}
  end

  def name(options = {})
  	with_trim = options[:trim] == nil
  	car_name = "#{self.year} #{self.make.name} #{self.model}"
  	return car_name + " #{self.trim}" if with_trim
  	car_name
  end

  Paperclip.interpolates :year do |attachment, style|
	  attachment.instance.year
	end

	Paperclip.interpolates :make do |attachment, style|
	  attachment.instance.make.name
	end

	Paperclip.interpolates :model do |attachment, style|
	  attachment.instance.model
	end

	Paperclip.interpolates :trim do |attachment, style|
	  attachment.instance.trim.blank? ? 'none' : attachment.instance.trim
	end

end
