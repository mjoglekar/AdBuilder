class GoogleFont < ActiveRecord::Base
	has_many :texts
	has_attached_file :file,
                    :path => "public/uploads/fonts/:id/:style_:extension",
                    :url => "uploads/fonts/:id/:style_:extension",
                    :use_timestamp => false
  do_not_validate_attachment_file_type :file
end
