class ClientMake < ActiveRecord::Base
  belongs_to :client
  belongs_to :make
end
