class OtherFont < ActiveRecord::Base
	has_many :texts
  has_attached_file :file, default_url: "/images/:style/missing.png"
  # do_not_validates_attachment_content_type :file, content_type: /\Aimage\/.*\Z/
  do_not_validate_attachment_file_type :file
  has_attached_file :file,
                    :storage => :s3,
                    :path => "other_fonts/:id/:style_:extension",
                    :s3_protocol => :https,
                    :s3_credentials => Proc.new{|a| a.instance.s3_credentials }
   def s3_credentials
    {:bucket => ENV['bucket'], :access_key_id => ENV['access_key_id'], :secret_access_key => ENV['secret_access_key']}
  end                   
end
