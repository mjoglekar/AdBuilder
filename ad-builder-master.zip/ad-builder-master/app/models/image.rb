class Image < ActiveRecord::Base
	# has_attached_file :file, default_url: "/images/:style/missing.png"
 #  validates_attachment_content_type :file, content_type: /\Aimage\/.*\Z/
 #  has_attached_file :file,
 #                    :storage => :s3,
 #                    :path => "images/:id/:style_:extension",
 #                    :s3_credentials => Proc.new{|a| a.instance.s3_credentials }

  belongs_to :ad
  belongs_to :client_logo
  belongs_to :promotional_logo
  belongs_to :car
  belongs_to :button
	has_one :element_animation
  default_scope { order(name: :desc) }

  attr_readonly(:name)

  validates :name, presence: true
  # before_save :validate_names
  # validates :name, :uniqueness => true
  
  amoeba do
    include_association :element_animation
  end

  def get_corresponding_image(template_ad)
    template_ad.images.find_or_create_by(name: self.name)
  end

  def validate_names
    self.name = 'promotional_logo' if self.promotional_logo
    self.name = 'button' if self.button
    self.name = 'car' if self.car
  end

  # def s3_credentials
  #   {:bucket => ENV['bucket'], :access_key_id => ENV['access_key_id'], :secret_access_key => ENV['secret_access_key']}
  # end
end
