class MakesBackgroundSet < ActiveRecord::Base
	belongs_to :background_set
	belongs_to :make
end
