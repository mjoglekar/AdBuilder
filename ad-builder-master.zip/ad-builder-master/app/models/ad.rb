class Ad < ActiveRecord::Base
	belongs_to :ad_group
	has_many :images
	has_many :texts
	belongs_to :background
	has_many :element_animations, through: :texts
	has_many :element_animations, through: :images
  default_scope { order(width: :desc) }

	has_attached_file :preview,
                    :path => "public/uploads/ads/:id/:style_:extension",
                    :url => "uploads/ads/:id/:style_:extension",
                    :use_timestamp => false
	validates_attachment_content_type :preview, content_type: /\Aimage\/.*\Z/

	before_destroy :check_if_template	

	amoeba do
    include_association :images
    include_association :texts
  end

  def check_if_template
  	return self.ad_group.is_template != true
  end

  def get_corresponding_ad(template_ad_group)
    template_ad_group.ads.find_by(width: self.width)
  end

  def self.sizes
  	return [[300, 250], [160,600], [728,90], [320,50]]
  end
	
	def get_image
		tmp_dir = File.join(Dir::tmpdir, "jpeg")
		FileUtils.remove_dir(tmp_dir) if Dir.exists?(tmp_dir)
		Dir.mkdir(tmp_dir)
		ad = self
		data = ""

    # thread = Thread.new do
			require 'open-uri'
			if Rails.env.development?
				puts "opening http://localhost:4000/ads/#{ad.id}/#{ad.width}"
				response = open("http://localhost:4000/ads/#{ad.id}/#{ad.width}").read
			else
				# Node horseman service (HTML to Image)
				response = open("https://stormy-ocean-64852.herokuapp.com/ads/#{ad.id}/#{ad.width}").read
			end
			puts "{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{"
			data = response
		  puts "{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{"
    # end

    # thread.join
    # thread.exit

		file = Tempfile.new("#{ad.id}", Dir.tmpdir)
    file.binmode
    file.write(data)
    file.flush
    puts file.path
		puts "after join"
		
		image = MiniMagick::Image.new(file.path)
    image.crop("#{ad.width}x#{ad.height}+0+0")
		# image.adaptive_resize("#{ad.width}x#{ad.height}")
		File.open(image.path) do |f|
			ad.update(preview: f)
			# ad.ad_group.update(preview: f) if ad.width == 300
		end
		ad.save!
		return ad.preview.url
		# return image.path
		
	end

	def downloadFont(googleFont)
		require 'net/http'
		require 'tempfile'
		require 'uri'
		file_url = "#{Dir::tmpdir}/#{googleFont.name.gsub(' ', '_')}.ttf"
		unless File.exists?(file_url)
			puts "downloading font ++++++++++++++++++++++++"
			resp = Net::HTTP.get_response(URI.parse(googleFont.download_url))
			file = File.open(file_url, 'wb' ) do |output|
		    output.write resp.body
		  end
		end
		return file_url
	end
end
