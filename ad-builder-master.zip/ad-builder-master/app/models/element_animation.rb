class ElementAnimation < ActiveRecord::Base
	belongs_to :image
	belongs_to :text
	belongs_to :animation
end
