class Button < ActiveRecord::Base
  belongs_to :background_set
  has_attached_file :file,
                    :storage => :s3,
                    :path => "background_set/:set/button_:id_:extension",
                    :s3_credentials => Proc.new{|a| a.instance.s3_credentials }
  do_not_validate_attachment_file_type :file
  
  def s3_credentials
    {:bucket => ENV['bucket'], :access_key_id => ENV['access_key_id'], :secret_access_key => ENV['secret_access_key']}
  end

  Paperclip.interpolates :set do |attachment, style|
    attachment.instance.background_set.id
  end                
end
