class Text < ActiveRecord::Base
	has_one :element_animation
	belongs_to :google_font
	belongs_to :other_font
  default_scope { order(name: :desc) }

	has_attached_file :file,
                    :path => "public/uploads/texts/:id/:style_:extension",
                    :url => "uploads/texts/:id/:style_:extension",
                    :use_timestamp => false
	validates_attachment_content_type :file, content_type: /\Aimage\/.*\Z/

	amoeba do
    include_association :element_animation
  end

  def get_corresponding_text(template_ad)
    template_ad.texts.find_or_create_by(name: self.name)
  end

  def get_image
    ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    puts "getting image for text #{self.id}"
    ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  	tmp_dir = File.join(Dir::tmpdir, "jpeg")
		FileUtils.remove_dir(tmp_dir) if Dir.exists?(tmp_dir)
		Dir.mkdir(tmp_dir)
		text = self
		data = ""

			require 'open-uri'
			if Rails.env.development?
				response = open("http://localhost:8891/?url=http://localhost:3000/texts/#{text.id}&width=#{text.width.to_i + 10}&height=#{text.height.to_i + 10}&zoom=2&format=PNG").read #stormy-ocean-64852.herokuapp.com
			else
				# Manet service
				response = open("https://calm-headland-96359.herokuapp.com/?url=https://ad-builder.herokuapp.com/texts/#{text.id}&width=#{text.width.to_i + 10}&height=#{text.height.to_i + 10}&zoom=2&format=PNG").read #stormy-ocean-64852.herokuapp.com
			end

			# response = open("http://localhost:4000/texts/#{text.id}/#{text.width.to_f}/#{text.height.to_f}").read #stormy-ocean-64852.herokuapp.com
			puts "{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{"
			data = response
		  puts "{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{"
		file = Tempfile.new("text_#{text.id}_#{rand(100)}", Dir.tmpdir)
    file.binmode
    file.write(data)
    file.flush
    puts file.path
		puts "after join"
		# image = MiniMagick::Image.new(file.path)
		# image.adaptive_resize("#{text.width}")
		# image.crop("#{text.width*1.5}x#{text.height*1.5}+0+0")
		File.open(file.path) do |f|
			text.update(file: f)
		end
		text.save!
		puts ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;"
		puts text.file.url
		puts ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;"
		return text.file.url
  end  
end
