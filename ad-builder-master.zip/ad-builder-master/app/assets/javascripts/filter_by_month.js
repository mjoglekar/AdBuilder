$(document).ready(function(){
	$('.find-by-month').on('change',function(){
		var foundMonth = $('#existing-ads-month').val();
		filterByMonth(foundMonth)
	});
});

function filterByMonth(foundMonth){
	var found = []
	var div = $('li.ad-group')
	$(div).each(function(){
		var month = $(this).attr('month')
		if(month == foundMonth){
			found.push(month)
			$(this).show()
		}
		else{
			$(this).hide()
		}
	});

}