$(document).ready(function(){
	$('.find-by-year').on('change',function(){
		var filterByYear = $('#existing-ad-year').val()
		filter(filterByYear)
	});
});

function filter(filterByYear){
	var found = []
	var div = $('li.ad-group')
	$(div).each(function(){
		var year = $(this).attr('year')
		if(year == filterByYear){
			found.push(year)
			$(this).show()
		}
		else{
			$(this).hide()
		}
	});

}