$(document).ready(function(){
	$("#ad_group_cost, #ad_group_client_name, #ad_group_optional1, #ad_group_optional2, #ad_group_optional3, #ad_group_optional4, #ad_group_optional5, #ad_group_car_year, #ad_group_term, #ad_group_apr, #ad_group_msrp, #ad_group_disclaimer").keyup(function() {
		var preview_id = $(this).attr('id').substring(9)
		$('div.html_preview .' + preview_id).text($(this).val());
		$('div#ad_0 .' + preview_id + ' span').text($(this).val());
	});

	$('#ad_group_client_name').on('change',function(){
 		updateCarName()
 	});
	
	$('#ad_group_car_year').on('change',function(){
		updateCarName()
	});

	$('select#model').chosen().on('change',function(){
		updateCarName()
	});

	$('select#trim').chosen().on('change',function(){
		updateCarName()
	});
});
function updateCarName(){
	var clientName = $('#ad_group_client_name').val()
	var make = $('select#make option:selected').text()
	var year = $('#ad_group_car_year').val()
	var	model = $("select#model").val()
	var trim = $('select#trim').val()
	if (trim == 'none') {
		trim = ''
	}
	$('.text.client_name').text(clientName)
	$('.text.car_year').text(year)
 	$('.text.make-model').text(make + " " + model)
	$('.text.trim').text(trim)
	$('.text.car_name').text(year +" " + make +" " + model)
}