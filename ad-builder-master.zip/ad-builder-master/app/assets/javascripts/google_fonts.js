$(document).ready(function(){
	$("input#spectrum").spectrum({
    showInput: true,
    preferredFormat: "rgb",
    move: function(color){
    	color.toHexString();
			$('.text.selected').css('color',color);
    },
    change: function(color) {
    	color.toHexString();
			$('.text.selected').css('color',color);
			updateFont();
    }
	});
	$('.text').on('click',function(event){
	 	event.preventDefault();
	  var font = $(this).css('font-family');
	  var googleFontID = "g" + $(this).attr('googlefont');
	  var otherFontID = "o" + $(this).attr('otherfont');
	  var fonts = font.replace(new RegExp("'","g"),"");
	  var fontSize = $(this).css('font-size');
	  var fontColor = $(this).css('color');
    var bold = $(this).hasClass('bold');
    var italic = $(this).hasClass('italic');
    var underline = $(this).hasClass('underline');
    var textAlign = $(this).css('text-align');
	  	
	  if (googleFontID !== "g") {
			$('select#fonts').val(googleFontID).trigger("chosen:updated");
	  } else {	
	  	$('select#fonts').val(otherFontID).trigger("chosen:updated");
	  }
		$('#font-size.chosen').val(fontSize).trigger("chosen:updated");
    $("input#spectrum").spectrum('set', fontColor);
    $('.bold-button').toggleClass('selected', bold);
    $('.italic-button').toggleClass('selected', italic);
    $('.underline-button').toggleClass('selected', underline);
    $('.align-button').removeClass('selected');
    $('.align-' + textAlign + '-button').addClass('selected');
 });

 $("select#fonts").chosen().change(function(){
 		updateFont()
 });
 $("select#font-size").chosen().change(function(){
 	updateFont()
 });

 $('select#color-font').change(function(){
 	updateFont()
 });
});

function updateFont(){
  var size = $("div.edit-panel.current select#font-size").val()
 	var fontID = $("div.edit-panel.current select#fonts").val();
 	if (fontID.substring(0,1) == 'g'){
	 	var googleFontID = fontID.substring(1)
 		var otherFontID = null
 		$('.text.selected').attr('googlefont', googleFontID)
 	} else {
	 	var googleFontID = null
	 	var otherFontID = fontID.substring(1)
 		$('.text.selected').attr('otherfont', otherFontID)
 	}
 	var fontName = $("div.edit-panel.current select#fonts option:selected").text();
 	var text = $('.text.selected');
	var color = $(".text.selected").css('color')
 	var id = $('.text.selected').attr('id');
  $('.text.selected').css('font-family',fontName)
  $('.text.selected').css('font-size',size)
	request = $.ajax({
		method: 'PUT',
		url: "/texts/" + id,
		dataType: 'json',
		data: {
			"google_font_id": googleFontID,
			"other_font_id": otherFontID,
			"font_family": fontName,
			"font_size": size,	
			"color": color
		}
	});
 };