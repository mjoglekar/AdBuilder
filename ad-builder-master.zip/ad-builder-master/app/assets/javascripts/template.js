$(document).ready(function(){
	$('.save-as-template').on('click',function(){
		var id = $(this).attr('id')
		$('#submit-template').attr('value', id)
	});
	$('#submit-template').on("click",function(){
		var formData = $('select#save_as_template_makes').val()
		var data = {"makes": formData}
		var id = $(this).attr('value')
		
		var request = $.ajax({
			method: "GET",
			url: '/ad_groups/' + id + '/save_as_template',
			data: data
		});
		request.done(function(response){
			$('a.close')[0].click();
		});
	});
});