$(document).ready(function(){
	$('.background-preview').on('click',function(){
		$('.background-preview').removeClass("active");
		$(this).addClass("active");
		var divId = $('.background-preview.active').attr('value');
		$('#ad_group_background_set_id').val(divId);
		var backgroundUrl = $('.background-preview.active img').attr('src');
		var buttonUrl = $('.background-preview.active').attr('button');
		$('.select-layout-item div.html_preview').css('background-image', 'url('+backgroundUrl+')');
		$('.select-layout-item div.html_preview img.button').attr('src', buttonUrl);
	});

	currentTemplate = $('#ad_group_template_id').val();
	$('.select-layout-item#current').addClass('active');

	$('.select-layout-item').on('click',function(){
		$('.select-layout-item').removeClass("active");
		$(this).addClass("active");
		var divId = $('.select-layout-item.active').attr('id');
		$('#ad_group_template_id').val(divId);
	});
});
