$(document).ready(function(){
	// Background Sets
	$('button.get-backgrounds').click(function(){
		var make_id = $(this).attr('id');
		$.ajax({
			method: 'GET',
			url: "/background_sets?make_id=" + make_id,
			dataType: 'html',
			success: function(data){
				$('div#render-backgrounds').empty();
				$('div#render-backgrounds').append(data);
			}
		})
	});

	// Promotional Logos
	$('button.get-promotional-logos').click(function(){
		var make_id = $(this).attr('id');
		$.ajax({
			method: 'GET',
			url: "/promotional_logos?make_id=" + make_id,
			dataType: 'html',
			success: function(data){
				$('div#render-promotional-logos').empty();
				$('div#render-promotional-logos').append(data);
			}
		})
	});

	// Templates
	$('button.get-templates').click(function(){
		var make_id = $(this).attr('id');
		$.ajax({
			method: 'GET',
			url: "/templates?make_id=" + make_id,
			dataType: 'html',
			success: function(data){
				$('div#render-templates').empty();
				$('div#render-templates').append(data);
			}
		})
	});

	//cars

	$('button.get-cars').click(function(){
		var make_id = $(this).attr('id')
		$(this).addClass('selected')
		var make = $('.selected').text()
		var year = $('select#year').val()
		$.ajax({
			method: 'GET',
			url: '/cars/'+ year + '/' + make_id,
			dataType: "json",
			success: function(data){
			 	$('#render-cars').empty();
				var car = ""
				if (data.length > 0){
					for (index = 0;index < data.length; index ++){
						carModel =	car + data[index]
						$('div#render-cars').append('<button id="car-model" class='+ carModel + '>' + carModel +  '</button>');
					}
				}
				else {
					$('div#render-cars').append("There are no cars");
				}
			 	$('button#car-model').click(function(){
			 		var modelData = $(this).text()
			 		$.ajax({
			 			method: 'GET',
			 			url: '/cars/' + year + '/' + make_id + '/' + modelData,
			 			dataType: 'html',
			 			success: function(data){
							$('#render-cars').html(data);
						}
			 		});

			 	});
		 	}
		});
	});
});