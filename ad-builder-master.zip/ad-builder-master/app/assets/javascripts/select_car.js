$(document).ready(function(){
	$('form.new_ad_group').on('submit',function(event){
		event.preventDefault();
		var carId = $('input#ad_group_car_id').val();
		if (carId == ""){
			alert("Please select a car image");
		}
		else {
			$('form.new_ad_group').unbind('submit').submit();
		}
	});
});

