$(document).ready(function(){
	$('#field-content-apr').hide();

	$('div.radio#uniform-lease-buy-ad-incentive-type-branded').click(function(){
		$('div.radio span').removeClass('checked');
		$(this).children().addClass('checked');
		$('.field-content').show();
		$('#field-content-apr').hide();
	});
	$('div.radio#uniform-lease-buy-ad-incentive-type-finance,div.radio#uniform-lease-buy-ad-incentive-type-buy,div.radio#uniform-lease-buy-ad-incentive-type-lease').click(function(){
		$('div.radio span').removeClass('checked');
		$(this).children().addClass('checked');
		$('.field-content').show();
		$('#field-content-optional2,#field-content-optional3,#field-content-optional4,#field-content-optional5').hide();
	});
});