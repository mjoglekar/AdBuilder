$(document).ready(function(){
	$('.align-left-button').on('click',function(){
		$('div.edit-panel.current  .text.selected').css('text-align','left');
    $('.align-button').removeClass('selected');
		$(this).toggleClass('selected');
		updateTextAlign("left");
		});
	$('.align-right-button').on('click',function(){
	  $('div.edit-panel.current .text.selected').css('text-align','right');
    $('.align-button').removeClass('selected');
	  $(this).toggleClass('selected');
  	updateTextAlign("right");
  });
	$('.align-center-button').on('click',function(){
		$('div.edit-panel.current .text.selected').css('text-align','center');
    $('.align-button').removeClass('selected');
		$(this).toggleClass('selected');
		updateTextAlign("center");
	});
		 
  function updateTextAlign(alignment){
   	var id = $('.text.selected').attr('id')
   	var request = $.ajax({
   		method: "PUT",
   		url: "/texts/" + id,
   		dataType: "json",
   		data:{
   			"text_align": alignment
   		}
   	});
  }
});