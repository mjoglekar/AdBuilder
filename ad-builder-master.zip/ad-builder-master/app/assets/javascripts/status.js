$(document).ready(function(){
	$('span.checked').on('click',function(){
	 	var checked = this
	 	var id = $(checked).parent().attr('id')
		$(checked).toggleClass('checked');
		filterByStatus();


		function filterByStatus(){
			var published = $('div#uniform-library-published-radio span').hasClass('checked')
			var pending = $('div#uniform-library-pending-radio span').hasClass('checked')
			var divs = $('li.ad-group');
			if (published && pending) {
				$(divs).show();
			} else if (!published && !pending) {
				$(divs).hide();
			} else if (published) {
				$('li.ad-group[status="true"]').show();
				$('li.ad-group[status="false"]').hide();
			} else {
				$('li.ad-group[status="true"]').hide();
				$('li.ad-group[status="false"]').show();
			}
		}
	});
});