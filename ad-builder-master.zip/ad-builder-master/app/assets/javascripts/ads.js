$(document).ready(function(){
	var id = $('div.ad').attr('id');
	$('div.edit-panel div.ad.html_preview').hide();
	$('div.edit-panel div.ad.img_preview').hide();

	$('button#html_preview').click(function(){
		$('.html_preview_container').html($('div.ad.html_preview').clone());
		$('div.ad.html_preview').show();
	});

	$('button#img_preview').click(function(){
		$.ajax({
			method: 'GET',
			url: "/ads/" + id + '/get_image',
			dataType: 'json',
			success: function(data){
				$('.img_preview_container').html("<img class='img_preview' src='"+data.link+"'/>");
				$('.img_preview_container').html($('.img_preview').clone());
			}
		})
	});


	$.each($('div.item-shape'), function() {
		var id = $(this).attr('id');
		$(this).click(function(){
			$('div.shadow-ads-wrapper.'+id).show();
			$('div.shadow-ads-wrapper.'+id).css('opacity', 1);
			$('div.edit-panel').removeClass('current');
			$('div.edit-panel.'+id).addClass('current');
			$('div.edit-panel.'+id).show();
			$('div.edit-panel.'+id).css('opacity', 1);
		})
	});

	$('img.print-ads-close').click(function(){
		hideEditPanel();
	});

	$('div.refresh-jpg').click(function(){
		var id = $('div.edit-panel.current div.ad').attr('id');
		var random = Math.floor(Math.random() * 10000)
		$.ajax({
			method: 'GET',
			url: '../../ads/' + id + '/get_image',
			dataType: 'json',
			beforeSend: function(){
				$('div.edit-panel.current div.preview-jpg').html('<img src="/assets/loading.GIF">');
		  },
			success: function(data){
				$('div.edit-panel.current div.preview-jpg').html('<img src="../../'+ data.link + '?' + random + '">');
			}
		})
	});

	$('div.refresh-swf').click(function(){
		var id = $('div.edit-panel.current div.ad').attr('id');
		$('div.edit-panel.current div.preview-swf iframe').attr('src', '../ads/'+id);
	});

	$('div.item-shape img').hide();
	$('div.approve').click(function(){
		var id = $('div.edit-panel.current').attr('id');
		$('div.item-shape.'+id+' img').show();
		hideEditPanel();
	});

});

function hideEditPanel(){
	$('div.shadow-ads-wrapper').hide();
	$('div.shadow-ads-wrapper').css('opacity', 0);
}