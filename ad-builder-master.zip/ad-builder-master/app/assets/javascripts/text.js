$(document).ready(function(){
	$('div.bold-button').on('click',function(){
		$(this).toggleClass('selected');
		$(".selected").toggleClass('bold');
		$(".selected").css('font-weight', '');
		updateTextStyle();
	});

	$('div.italic-button').on('click',function(){
		$(this).toggleClass('selected');
		$(".selected").toggleClass('italic');
		$(".selected").css('font-style', '');
		updateTextStyle();
	});

	$('div.underline-button').on('click',function(){
		$(this).toggleClass('selected');
		$('.selected').toggleClass('underline');
		$('.selected').css('text-decoration', '');
		updateTextStyle();
	});

	function updateTextStyle(){
		var id = $('.text.selected').attr('id')
		var bold = $(".selected").hasClass('bold')
		var italic = $('.selected').hasClass('italic')
		var underline = $('.selected').hasClass('underline')
		var request = $.ajax({
		 method: "PUT",
		 url: '/texts/' + id,
		 dataType: 'json',
		 data: {
		 	 "bold": bold,
		 	 "italic": italic,
		 	 "underline_text": underline
		 }
		});
	}
});



