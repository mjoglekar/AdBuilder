$(document).ready(function(){
	$('.nudget-arrow.up-arrow').click(function(){
		var current_y = parseInt(getSelected().css('top'));
		getSelected().css('top', (current_y - 2).toString() + 'px');
		update();
	});
	$('.nudget-arrow.down-arrow').click(function(){
		var current_y = parseInt(getSelected().css('top'));
		getSelected().css('top', (current_y + 2).toString() + 'px');
		update();
	});
	$('.nudget-arrow.left-arrow').click(function(){
		var current_x = parseInt(getSelected().css('left'));
		getSelected().css('left', (current_x - 2).toString() + 'px');
		update();
	});
	$('.nudget-arrow.right-arrow').click(function(){
		var current_x = parseInt(getSelected().css('left'));
		getSelected().css('left', (current_x + 2).toString() + 'px');
		update();
	});
});

function update() {
	var element = getSelected();
	var type = $('.selected').hasClass("image") ? 'images' : 'texts';
	$.ajax({
    type: "PUT",
		url: "../" + type + "/" + element.attr('id'),
    data: {
      "x":element.css('left'),
      "y":element.css('top')
    }
  });
}