$(document).ready(function(){
	$("select#animations").change(function(){
		var animation = $("div.edit-panel.current select#animations").val();
		$('.text.selected, .image.selected').attr('animation', animation);
		$('.text.selected, .image.selected').animateCss(animation);
		updateAnimation();
	});

	$("input#animation-duration").change(function(){
		var duration = $("div.edit-panel.current input#animation-duration").val();
		$('.text.selected, .image.selected').css('animation-duration', duration + 's');
		updateAnimation();
	});

	$("input#animation-start").change(function(){
		var start = $("div.edit-panel.current input#animation-start").val();
		$('.text.selected, .image.selected').attr('animation-start', start + 's');
		updateAnimation();
	});

	$(".text, .image").click(function(){
		var animation = $('.text.selected, .image.selected').attr('animation').replace(new RegExp("'","g"),"");
		$("select#animations").val(animation).trigger("chosen:updated");
		var duration = $('.text.selected, .image.selected').css('animation-duration');
		if (duration == '0s'){
			duration = '1s';
		}
		$("input#animation-duration").val((/\d+/).exec(duration));
		var start = $('.text.selected, .image.selected').attr('animation-start');
		$("input#animation-start").val((/\d+/).exec(start));
	})
});

function updateAnimation(){
	var type = $('.text.selected, .image.selected').hasClass("image") ? 'images' : 'texts';
	var id = $('.text.selected, .image.selected').attr('id');
	var animation = $('.text.selected, .image.selected').attr('animation');
	var duration = $('.text.selected, .image.selected').css('animation-duration');
	var start = $('.text.selected, .image.selected').attr('animation-start');

	request = $.ajax({
		method: 'PUT',
		url: "/"+ type + "/" + id + "/animations/1",
		dataType: 'json',
		data: {
			"animation": animation,
			"duration": duration,	
			"start_time": start
		}
	});
}


$.fn.extend({
  animateCss: function (animationName) {
	  var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
	  $(this).addClass('animated ' + animationName).one(animationEnd, function() {
      $(this).removeClass('animated ' + animationName);
	  });
  }
});