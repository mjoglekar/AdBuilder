$(document).ready(function(){
	$('#existing-ads-client-name').on('change', function(){
		var inputVal = $('#existing-ads-client-name').val();
		var searchVal = inputVal.toLowerCase();
		search(searchVal)
	});
});

function search(searchVal){
	var found = new RegExp(searchVal);
	var matches = []
	var div = $('li.ad-group')
	$(div).each(function(){
		var name = $(this).attr('name')
		var downcaseName = name.toLowerCase()
		if(downcaseName.match(found)){
			matches.push(name)
			$(this).show();
		}
		else {
			$(this).hide();
		}
	});
	return matches
}	