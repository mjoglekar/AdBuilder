$(document).ready(function(){
	$('.minus-zindex').on('click',function(){
		var currentZindex = $('div.edit-panel.current .selected').css('z-index');
		var newIndex = parseInt(currentZindex) -1 
	  indexToS = newIndex.toString()
		$('div.edit-panel.current .selected').css('z-index',indexToS)
		updateZIndex(newIndex)
	});

	$('.plus-zindex').on('click', function(){
		var currentZindex = $('div.edit-panel.current .selected').css('z-index');
		var newIndex = parseInt(currentZindex) + 1
	  indexToS = newIndex.toString()
		$('div.edit-panel.current .selected').css('z-index',indexToS)
		updateZIndex(newIndex)
	});

	$('.send-zindex').on('click',function(){
		var min = findLowestZIndex();
		$('div.edit-panel.current .selected').css('z-index', (min - 1).toString());
		updateZIndex(min - 1)
	});

	$('.bring-zindex').on('click',function(){
		var max = findHighestZIndex();
		$('div.edit-panel.current .selected').css('z-index', (max + 1).toString());
		updateZIndex(max + 1)
	});

	function updateZIndex(zindex){
		zindex =  parseInt(zindex)
		var type = $('.selected').hasClass("image") ? 'images' : 'texts';
		var id = $('.selected').attr('id')
		var request = $.ajax({
			method: "PUT",
			url: "/" + type + "/" + id,
			dataType: "json",
			data:{
				"z_index": zindex
			}
		});
	}

	function findLowestZIndex(){
		var min = parseInt($('.selected').css('z-index'));
		$.each($('div.text, img.image'), function(i, el) {
			var zIndex = parseInt($(el).css('z-index'));
			if (zIndex < min){
				min = zIndex;
			}
		});
		return min;
	}

	function findHighestZIndex(){
		var max = parseInt($('.selected').css('z-index'));
		$.each($('div.text, img.image'), function(i, el) {
			var zIndex = parseInt($(el).css('z-index'));
			if (zIndex > max){
				max = zIndex;
			}
		});
		return max;
	}

});