

$(document).ready(function(){
  

  var data = {"src":"https://www.globalbrigades.org/media_gallery/thumb/320/0/Engineering_2014_Icon_Small.png",
              "animation":"bounceIn",
              "startTime":"0"}

  $.fn.extend({
    animateCss: function (animationName) {
        var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        $(this).addClass('animated ' + animationName).one(animationEnd, function() {
            $(this).removeClass('animated ' + animationName);
        });
    }
  });

  $('#animate').click(function(){
    $.each($('.image, .text'), function(){
      $(this).animateCss($(this).attr('data-animation'));
    })
  });

  function updateForms(target){
    var animation = target.getAttribute('data-animation');
    $('select#animation').val(animation);
    var startTime = target.getAttribute('data-startTime');
    $('input#startTime').val(startTime);
    var fontSize = parseInt($('.selected').css('font-size').match(/\d+/)[0]);
    $('input#fontSize').val(fontSize);
  }

  $('select#animation').change(function(){
    var target = $('.selected')[0];
    var animation = $(this).val();
    target.setAttribute('data-animation', animation);
  });

  $('input#startTime').change(function(){
    var target = $('.selected')[0];
    var startTime = $(this).val();
    target.setAttribute('data-startTime', startTime);
    $('.selected').css('-webkit-animation-delay', startTime + 's');
    $('.selected').css('animation-delay', startTime + 's');
  });

  $('input#fontSize').change(function(){
    var target = $('.selected')[0];
    var fontSize = $(this).val();
    target.setAttribute('data-fontSize', fontSize);
    $('.selected.text').css('font-size', fontSize + 'px');
  });

  $('.plus-edit').click(function(){
    if ($('.selected.text').length != 0) {
      var newSize = parseInt(getSelected().css('font-size')) + 1;
      $('select#font-size').val(newSize + 'px').trigger('chosen:updated')
      $('.selected.text').css('font-size', newSize + 'px');
      updateFont();
    } else {
      updateImageSize();
    }
  });

  $('.minus-edit').click(function(){
    var newSize = parseInt(getSelected().css('font-size')) - 1;
    $('select#font-size').val(newSize + 'px').trigger('chosen:updated')
    $('.selected.text').css('font-size', newSize + 'px');
    updateFont();
  });

  function dragMoveListener (event) {
    var target = event.target,
        // keep the dragged position in the data-x/data-y attributes
        x = (parseFloat(target.style.left) || 0) + event.dx,
        y = (parseFloat(target.style.top) || 0) + event.dy;

    // translate the element
    // target.style.webkitTransform =
    target.style.left = target.style.left = x + 'px';
    target.style.top = target.style.top = y + 'px';

    // update the posiion attributes
    target.setAttribute('data-x', x);
    target.setAttribute('data-y', y);
    // target.classList.toggle('selected');
  }

  // this is used later in the resizing and gesture demos
  window.dragMoveListener = dragMoveListener;  


  interact('div.module.ad-preview .image')
  .draggable({
    onmove: window.dragMoveListener
  })
  .resizable({
    preserveAspectRatio: true,
    edges: { right: true, bottom: true }
  })
  .on('resizemove', function (event) {
    var target = event.target,
        x = (parseFloat(target.style.left) || 0),
        y = (parseFloat(target.style.top) || 0);

    // update the element's style
    target.style.width  = event.rect.width + 'px';
    target.style.height = event.rect.height + 'px';

    // translate when resizing from top or left edges
    x += event.deltaRect.left;
    y += event.deltaRect.top;

    target.setAttribute('data-x', x);
    target.setAttribute('data-y', y);
  })
  .on('dragend resizeend', function(event) {
    var target = event.target
    $.ajax({
      type: "PUT",
      url: "../images/" + target.id,
      data: {
        "x":target.style.left,
        "y":target.style.top,
        "width":target.style.width,
        "height":target.style.height
      }
    })
  })
  .on('tap', function (event) {
    $('.image, .text').removeClass('selected');
    event.currentTarget.classList.toggle('selected');
    event.preventDefault();
    updateForms(event.target);
  })
  .on('doubletap', function (event) {
    event.currentTarget.classList.toggle('hidden');
    event.preventDefault();
    updateImage(event.currentTarget)
  });

  interact('div.module.ad-preview .text')
  .draggable({
    onmove: window.dragMoveListener
  })
  .resizable({
    // preserveAspectRatio: true,
    edges: { right: true, bottom: true }
  })
  .on('resizemove', function (event) {
    var target = event.target,
        x = (parseFloat(target.style.left) || 0),
        y = (parseFloat(target.style.top) || 0);

    // update the element's style
    target.style.width  = event.rect.width + 'px';
    target.style.height = event.rect.height + 'px';

    // translate when resizing from top or left edges
    x += event.deltaRect.left;
    y += event.deltaRect.top;

    target.setAttribute('data-x', x);
    target.setAttribute('data-y', y);
  })
  .on('dragend resizeend', function(event) {
    var target = event.target
    $.ajax({
      type: "PUT",
      url: "../texts/" + target.id,
      data: {
        "x":target.style.left,
        "y":target.style.top,
        "width":target.style.width,
        "height":target.style.height
      }
    })
  })
  .on('tap', function (event) {
    $('.image, .text').removeClass('selected');
    event.currentTarget.classList.toggle('selected');
    event.preventDefault();
    updateForms(event.target);
  })
  .on('doubletap', function (event) {
    event.currentTarget.classList.toggle('hidden');
    event.preventDefault();
    updateText(event.currentTarget)
  });

  
  $('div#approve-all').click(function(){
    $('div.item-shape img').css('display', 'inline');
    $('div#ad-preview-save-continue').removeClass('disabled');
  });

  $('div.module.publish img.loading').hide();

  $('div.checker.conditional-promo-logo').click(function(){
    togglePromoLogoInJpeg();
  });
});

function updateText(target, hide) {
  $.ajax({
    type: "PUT",
    url: "../texts/" + target.id,
    data: {
      "hidden": getSelected().hasClass('hidden')
    }
  })
}

function updateImage(target, hide) {
  $.ajax({
    type: "PUT",
    url: "../images/" + target.id,
    data: {
      "hidden": getSelected().hasClass('hidden')
    }
  })
}

function updateImageSize() {
  var newWidth = parseInt($('.selected.image').css('width')) + 1;
  var id = $('.selected.image').attr('id');
  $('.selected.image').css('width', newWidth + 'px');
  request = $.ajax({
    method: 'PUT',
    url: "/images/" + id,
    dataType: 'json',
    data: {
      "width": newWidth
    }
  });
}

function togglePromoLogoInJpeg() {
  $('div.checker.conditional-promo-logo span').toggleClass('checked');
  var ad_id = $('div.edit-panel.current div.ad').attr('id');
  var showPromoLogo = $('div.checker.conditional-promo-logo span').hasClass('checked');
  $.ajax({
    type: "PUT",
    url: "../ads/" + ad_id,
    data: {
      "show_promo_logo": showPromoLogo
    }
  });
}