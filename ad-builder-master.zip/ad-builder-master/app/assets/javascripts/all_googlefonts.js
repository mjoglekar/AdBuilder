$(document).ready(function(){
	$('#all-fonts .font').on('click',function(){
		var font = $(this)
		var id = $(font).attr("id")
		if (id == "50" || id =="35") {
			return false;
		}
		$(font).toggleClass("in-used");
		var inUsed = $(font).hasClass("in-used")
			var request = $.ajax({
			method: "put",
			url: '/google_fonts/' + id,
			dataType: 'json',
			data: {
				"in_use": inUsed
			}
		});
	});
});