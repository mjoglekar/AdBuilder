$(document).ready(function(){
	if ($("select#promotional_logo").chosen().val() != 'None' && $('div.module.ad-form').length > 0) {
		updatePromotionalLogoPreview();
	}

	$("select#make").on('change', function(){
		var $el = $("select#promotional_logo");
		$el.empty();
		$el.append($("<option value='0' selected>None</option>"));
		$('#promotional-logo-preview').hide()
		updatePromotionalLogoPreview()

		make_id = $("select#make").chosen().val();
		$.ajax({
			method: "GET",
			data: {"make_id":make_id},
			url: "/promotional_logos",
			dataType: "json"
		})
		.done(function(data){
			$.each(data, function(key,value) {
			  $el.append($("<option></option>").attr("value", value.id).text(value.name));
			});
			$el.trigger("chosen:updated");
		});
	});
	
	$("select#promotional_logo").on('change',function(){
		updatePromotionalLogoPreview()
	});

	function updatePromotionalLogoPreview(){
		var id = $("select#promotional_logo").chosen().val()
		if (id != 'None' && id != 0){ // selected promotional logo
			$('#promotional_logo_id').val(id)
			$('#promotional-logo-preview').show()
			var request = $.ajax({
				method: "GET",
				url: "/promotional_logos/" + id,
				dataType: "html"
			});
			request.done(function(data){
				$('#promotional-logo-preview').html(data)
			});
		} else { // did not select promotional logo
			$('#promotional-logo-preview').hide()
		}
	}
});