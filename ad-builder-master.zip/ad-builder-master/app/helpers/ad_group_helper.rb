module AdGroupHelper

	def element_animation
		
	end
end
