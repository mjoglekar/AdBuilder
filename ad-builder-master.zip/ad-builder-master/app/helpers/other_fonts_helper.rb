module OtherFontsHelper

	def get_other_fonts_css
		css = ""
		OtherFont.all.each do |font|
			css += get_other_font_css(font)
		end
		return css
	end

	def get_other_font_css(font)
		return "@font-face { font-family: '#{font.name}'; src: url(#{font.file.url}); font-weight: normal; font-style: normal; }"
	end

end
