module ClientHelper

	def search_client
		# search = "%#{search}%"
		# Client.where("name LIKE ?", search)

	  @clients = Client.all
  	if params[:search]
   	 	@clients = Client.search(params[:search]).order("id DESC")
  	else
    	@clients = Client.all.order('id DESC')
  	end
	end
end
