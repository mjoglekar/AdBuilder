module BackgroundSetHelper

	def missing_assets(background_set)
		# @background_set = BackgroundSet.last
		missing = []
	  [[300, 250],[160,600],[728,90],[320,50]].each do |dimensions|
	    found = false 
      background_set.backgrounds.each do |background|
      	if background.width == dimensions[0] && background.height == dimensions[1]
        	found = true
        end
      end
      missing << dimensions if not found
	  end
	  if missing != [] 
	  	return missing
	  end
	end

	def preview_backgrounds(make)
		@preview_backgrounds = []
		background_sets = make.background_sets
		background_sets.each do |sets|
			@preview_backgrounds << sets.backgrounds.where(width: 300).first
		end
		@preview_backgrounds
	end

	# def delete_sets
	# 	backgrounds_found = []
	# 	background_set = 
	# 	BackgroundSet.all.each do |set|
	# 		backgrounds_found << set.backgrounds.where(width: 300, height: 250)
	# 	end
	# 	return backgrounds_found
	# end
end
