module AdsHelper
end
