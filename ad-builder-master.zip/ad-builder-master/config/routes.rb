Rails.application.routes.draw do

  root 'welcome#index'
  resources :ad_groups
  resources :ads
  resources :images
  resources :texts
  resources :cars
  resources :google_fonts
  resources :other_fonts
  resources :backgrounds
  resources :background_sets
  resources :promotional_logos
  resources :makes
  resources :templates
  resources :clients

  put 'texts/:text_id/animations/:id' => 'texts#update_animation'
  put 'images/:image_id/animations/:id' => 'images#update_animation'
  get 'cars/:year/:make/:model' => 'cars#index'
  get 'cars/:year/:make' => 'cars#get_models'
  get 'trims/:year/:make/:model' => 'cars#get_trims'
  get 'cars/:year/:make/:model/:trim' => 'cars#show_all'
  get 'make/:id/promotional_logos' => 'promotional_logos#get_all'
  get 'ad_groups/:id/background' => 'ad_groups#choose_background', as: :choose_background
  post 'ad_groups/:id/update_background' => 'ad_groups#update_background'
  get 'ad_groups/:id/publish' => 'ad_groups#finalize', as: :finalize
  get 'ad_groups/:id/download' => 'ad_groups#publish', as: :publish
  get 'ad_groups/:id/edit_as_new' => 'ad_groups#edit_as_new', as: :edit_as_new
  get 'ad_groups/:id/save_as_template' => 'ad_groups#save_as_template', as: :save_as_template
  get 'ad_groups/:id/get_jpegs' => 'ad_groups#get_jpegs'
  get 'ad_groups/:id/preview' => 'ad_groups#preview'
  get 'ads/:id/get_image' => 'ads#get_image'
  get 'texts/:id/get_image' => 'texts#get_image'
  get 'admin' => 'welcome#backend'
  get 'backend' => 'welcome#backend'
  get 'backend/templates' => 'templates#backend'
  get 'backend/backgrounds' => 'background_sets#backend'
  get 'backend/promotional_logos' => 'promotional_logos#backend'
  get 'backend/cars' => 'cars#backend'
  get 'backend/fonts' => 'welcome#fonts'
  delete 'cars/:id' => 'cars#destroy', as: :delete_car
  delete 'background_sets/:id' => 'backgrounds_sets#destroy',as: :delete_background_set
  delete 'promotional_logos/:id' => 'promotional_logos#destroy', as: :delete_logo
  delete 'other_fonts/:id' => 'other_fonts#destroy', as: :delete_font
  delete 'templates/:id' => 'templates#destroy', as: :delete_template

  # post 'background_set' => 'background_set#create',as: 'background_set_path'
  
  
  # resources :texts
  # The priority is based upon order of creation: first created -> highest priority.
  # See how all your routes lay out with "rake routes".

  # You can have the root of your site routed with "root"
  # root 'welcome#index'

  # Example of regular route:
  #   get 'products/:id' => 'catalog#view'

  # Example of named route that can be invoked with purchase_url(id: product.id)
  #   get 'products/:id/purchase' => 'catalog#purchase', as: :purchase

  # Example resource route (maps HTTP verbs to controller actions automatically):
  #   resources :products

  # Example resource route with options:
  #   resources :products do
  #     member do
  #       get 'short'
  #       post 'toggle'
  #     end
  #
  #     collection do
  #       get 'sold'
  #     end
  #   end

  # Example resource route with sub-resources:
  #   resources :products do
  #     resources :comments, :sales
  #     resource :seller
  #   end

  # Example resource route with more complex sub-resources:
  #   resources :products do
  #     resources :comments
  #     resources :sales do
  #       get 'recent', on: :collection
  #     end
  #   end

  # Example resource route with concerns:
  #   concern :toggleable do
  #     post 'toggle'
  #   end
  #   resources :posts, concerns: :toggleable
  #   resources :photos, concerns: :toggleable

  # Example resource route within a namespace:
  #   namespace :admin do
  #     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
  #     resources :products
  #   end
end
